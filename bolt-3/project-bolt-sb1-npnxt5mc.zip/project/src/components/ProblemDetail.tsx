import React, { useState, useEffect } from 'react';
import { Problem } from '../types/Problem';
import { CodeEditor } from './CodeEditor';
import { TestResults } from './TestResults';
import { ArrowLeft } from 'lucide-react';

interface ProblemDetailProps {
  problem: Problem;
  onBack: () => void;
  onComplete: (problemId: number) => void;
}

interface TestResult {
  passed: boolean;
  input: string;
  expected: string;
  actual: string;
}

export const ProblemDetail: React.FC<ProblemDetailProps> = ({
  problem,
  onBack,
  onComplete
}) => {
  const [currentCode, setCurrentCode] = useState(problem.starterCode);
  const [testResults, setTestResults] = useState<TestResult[]>([]);
  const [isRunning, setIsRunning] = useState(false);

  useEffect(() => {
    setCurrentCode(problem.starterCode);
    setTestResults([]);
  }, [problem]);

  const getDifficultyColor = (difficulty: string) => {
    switch (difficulty) {
      case 'Easy': return 'text-green-600 bg-green-50 border-green-200';
      case 'Medium': return 'text-yellow-600 bg-yellow-50 border-yellow-200';
      case 'Hard': return 'text-red-600 bg-red-50 border-red-200';
      default: return 'text-gray-600 bg-gray-50 border-gray-200';
    }
  };

  const runTests = (code: string) => {
    setIsRunning(true);
    
    // Simulate test execution with a delay
    setTimeout(() => {
      const results: TestResult[] = problem.testCases.map((testCase, index) => {
        // Simulate test results - in a real implementation, you'd execute the code
        // For demo purposes, we'll randomly pass/fail some tests
        const passed = Math.random() > 0.3; // 70% pass rate for demo
        
        return {
          passed,
          input: testCase.input,
          expected: testCase.expectedOutput,
          actual: passed ? testCase.expectedOutput : 'null'
        };
      });
      
      setTestResults(results);
      setIsRunning(false);
      
      // Check if all tests passed
      if (results.every(r => r.passed)) {
        onComplete(problem.id);
      }
    }, 1500);
  };

  const resetCode = () => {
    setTestResults([]);
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
      <div className="mb-6">
        <button
          onClick={onBack}
          className="flex items-center text-blue-600 hover:text-blue-700 mb-4"
        >
          <ArrowLeft className="h-4 w-4 mr-1" />
          Back to Problems
        </button>
        
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold text-gray-900">{problem.title}</h1>
            <div className="flex items-center mt-2 space-x-4">
              <span className={`inline-flex px-3 py-1 text-sm font-semibold rounded-full border ${getDifficultyColor(problem.difficulty)}`}>
                {problem.difficulty}
              </span>
              <span className="text-sm text-gray-600">{problem.category}</span>
            </div>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Problem Description */}
        <div className="space-y-6">
          <div className="bg-white rounded-lg border border-gray-200 p-6">
            <h2 className="text-lg font-semibold text-gray-900 mb-4">Description</h2>
            <div className="prose prose-sm max-w-none">
              <p className="text-gray-700 whitespace-pre-line">{problem.description}</p>
            </div>
          </div>

          <div className="bg-white rounded-lg border border-gray-200 p-6">
            <h2 className="text-lg font-semibold text-gray-900 mb-4">Examples</h2>
            <div className="space-y-4">
              {problem.examples.map((example, index) => (
                <div key={index} className="border-l-4 border-blue-200 pl-4">
                  <div className="text-sm">
                    <div className="mb-1">
                      <span className="font-semibold text-gray-700">Input:</span>
                      <code className="ml-2 text-blue-600 bg-blue-50 px-1 rounded">{example.input}</code>
                    </div>
                    <div className="mb-1">
                      <span className="font-semibold text-gray-700">Output:</span>
                      <code className="ml-2 text-green-600 bg-green-50 px-1 rounded">{example.output}</code>
                    </div>
                    {example.explanation && (
                      <div className="text-gray-600 text-xs mt-1">
                        <span className="font-semibold">Explanation:</span> {example.explanation}
                      </div>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div className="bg-white rounded-lg border border-gray-200 p-6">
            <h2 className="text-lg font-semibold text-gray-900 mb-4">Constraints</h2>
            <ul className="space-y-2 text-sm text-gray-700">
              {problem.constraints.map((constraint, index) => (
                <li key={index} className="flex items-start">
                  <span className="inline-block w-2 h-2 bg-gray-400 rounded-full mt-2 mr-3 flex-shrink-0"></span>
                  <code className="bg-gray-50 px-1 rounded">{constraint}</code>
                </li>
              ))}
            </ul>
          </div>
        </div>

        {/* Code Editor and Results */}
        <div className="space-y-6">
          <CodeEditor
            initialCode={problem.starterCode}
            onCodeChange={setCurrentCode}
            onRun={runTests}
            onReset={resetCode}
          />
          
          <TestResults results={testResults} isRunning={isRunning} />
        </div>
      </div>
    </div>
  );
};