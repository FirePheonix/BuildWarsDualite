import React from 'react';
import { CheckCircle, XCircle, Clock } from 'lucide-react';

interface TestResult {
  passed: boolean;
  input: string;
  expected: string;
  actual: string;
}

interface TestResultsProps {
  results: TestResult[];
  isRunning: boolean;
}

export const TestResults: React.FC<TestResultsProps> = ({ results, isRunning }) => {
  if (isRunning) {
    return (
      <div className="bg-white rounded-lg border border-gray-200 p-6">
        <div className="flex items-center justify-center">
          <Clock className="h-5 w-5 text-blue-500 animate-spin mr-2" />
          <span className="text-gray-600">Running tests...</span>
        </div>
      </div>
    );
  }

  if (results.length === 0) {
    return (
      <div className="bg-white rounded-lg border border-gray-200 p-6">
        <p className="text-gray-500 text-center">Click "Run Code" to test your solution</p>
      </div>
    );
  }

  const passedTests = results.filter(r => r.passed).length;

  return (
    <div className="bg-white rounded-lg border border-gray-200">
      <div className="px-4 py-3 border-b border-gray-200 bg-gray-50">
        <div className="flex items-center justify-between">
          <span className="text-sm font-medium text-gray-700">Test Results</span>
          <span className={`text-sm font-semibold ${passedTests === results.length ? 'text-green-600' : 'text-red-600'}`}>
            {passedTests}/{results.length} tests passed
          </span>
        </div>
      </div>
      
      <div className="p-4 space-y-4">
        {results.map((result, index) => (
          <div
            key={index}
            className={`p-3 rounded-lg border ${
              result.passed 
                ? 'border-green-200 bg-green-50' 
                : 'border-red-200 bg-red-50'
            }`}
          >
            <div className="flex items-center mb-2">
              {result.passed ? (
                <CheckCircle className="h-4 w-4 text-green-500 mr-2" />
              ) : (
                <XCircle className="h-4 w-4 text-red-500 mr-2" />
              )}
              <span className="text-sm font-medium">
                Test Case {index + 1}
              </span>
            </div>
            
            <div className="text-xs space-y-1">
              <div>
                <span className="font-semibold text-gray-600">Input:</span>
                <span className="ml-2 font-mono bg-gray-100 px-1 rounded">{result.input}</span>
              </div>
              <div>
                <span className="font-semibold text-gray-600">Expected:</span>
                <span className="ml-2 font-mono bg-gray-100 px-1 rounded">{result.expected}</span>
              </div>
              {!result.passed && (
                <div>
                  <span className="font-semibold text-red-600">Got:</span>
                  <span className="ml-2 font-mono bg-red-100 px-1 rounded">{result.actual}</span>
                </div>
              )}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};