import React, { useState, useMemo } from 'react';
import { Header } from './components/Header';
import { ProblemList } from './components/ProblemList';
import { ProblemDetail } from './components/ProblemDetail';
import { problems } from './data/problems';
import { Problem } from './types/Problem';
import { useLocalStorage } from './hooks/useLocalStorage';

function App() {
  const [currentView, setCurrentView] = useState<'list' | 'detail'>('list');
  const [selectedProblem, setSelectedProblem] = useState<Problem | null>(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedDifficulty, setSelectedDifficulty] = useState('All');
  const [selectedCategory, setSelectedCategory] = useState('All');
  const [completedProblems, setCompletedProblems] = useLocalStorage<number[]>('completedProblems', []);

  // Add completion status to problems
  const problemsWithStatus = useMemo(() => {
    return problems.map(problem => ({
      ...problem,
      completed: completedProblems.includes(problem.id)
    }));
  }, [completedProblems]);

  // Filter problems based on search and filters
  const filteredProblems = useMemo(() => {
    return problemsWithStatus.filter(problem => {
      const matchesSearch = problem.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
                           problem.description.toLowerCase().includes(searchTerm.toLowerCase());
      const matchesDifficulty = selectedDifficulty === 'All' || problem.difficulty === selectedDifficulty;
      const matchesCategory = selectedCategory === 'All' || problem.category === selectedCategory;
      
      return matchesSearch && matchesDifficulty && matchesCategory;
    });
  }, [problemsWithStatus, searchTerm, selectedDifficulty, selectedCategory]);

  const handleProblemSelect = (problem: Problem) => {
    setSelectedProblem(problem);
    setCurrentView('detail');
  };

  const handleBackToList = () => {
    setCurrentView('list');
    setSelectedProblem(null);
  };

  const handleProblemComplete = (problemId: number) => {
    if (!completedProblems.includes(problemId)) {
      setCompletedProblems(prev => [...prev, problemId]);
    }
  };

  const completedCount = completedProblems.length;
  const totalProblems = problems.length;

  return (
    <div className="min-h-screen bg-gray-50">
      <Header searchTerm={searchTerm} onSearchChange={setSearchTerm} />
      
      {currentView === 'list' ? (
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
          <div className="mb-6">
            <div className="bg-white rounded-lg border border-gray-200 p-4 mb-6">
              <div className="flex items-center justify-between">
                <div>
                  <h2 className="text-lg font-semibold text-gray-900">Progress</h2>
                  <p className="text-sm text-gray-600">
                    {completedCount} of {totalProblems} problems solved
                  </p>
                </div>
                <div className="text-right">
                  <div className="text-2xl font-bold text-blue-600">
                    {Math.round((completedCount / totalProblems) * 100)}%
                  </div>
                  <div className="text-xs text-gray-500">Complete</div>
                </div>
              </div>
              <div className="mt-3 bg-gray-200 rounded-full h-2">
                <div
                  className="bg-blue-600 h-2 rounded-full transition-all duration-300"
                  style={{ width: `${(completedCount / totalProblems) * 100}%` }}
                ></div>
              </div>
            </div>
          </div>
          
          <ProblemList
            problems={filteredProblems}
            onProblemSelect={handleProblemSelect}
            selectedDifficulty={selectedDifficulty}
            onDifficultyChange={setSelectedDifficulty}
            selectedCategory={selectedCategory}
            onCategoryChange={setSelectedCategory}
          />
        </div>
      ) : (
        selectedProblem && (
          <ProblemDetail
            problem={selectedProblem}
            onBack={handleBackToList}
            onComplete={handleProblemComplete}
          />
        )
      )}
    </div>
  );
}

export default App;