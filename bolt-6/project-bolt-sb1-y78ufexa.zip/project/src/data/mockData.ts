import { Article, Author } from '../types/blog';

export const mockAuthors: Author[] = [
  {
    name: 'Sarah Chen',
    bio: 'Tech writer passionate about web development and design. Writing about the latest trends in frontend development.',
    avatar: 'https://images.pexels.com/photos/1239291/pexels-photo-1239291.jpeg?w=150&h=150&fit=crop&crop=face',
    followersCount: 1200,
    articlesCount: 24,
  },
  {
    name: 'Marcus Rodriguez',
    bio: 'Full-stack developer and startup founder. Sharing insights on building scalable web applications.',
    avatar: 'https://images.pexels.com/photos/220453/pexels-photo-220453.jpeg?w=150&h=150&fit=crop&crop=face',
    followersCount: 850,
    articlesCount: 18,
  },
  {
    name: 'Emma Thompson',
    bio: 'UX designer and researcher focused on creating intuitive digital experiences.',
    avatar: 'https://images.pexels.com/photos/1181519/pexels-photo-1181519.jpeg?w=150&h=150&fit=crop&crop=face',
    followersCount: 2100,
    articlesCount: 31,
  },
];

export const mockArticles: Article[] = [
  {
    id: '1',
    title: 'The Future of React: What\'s Coming in 2025',
    content: `# The Future of React: What's Coming in 2025

React has been the dominant frontend framework for years, and 2025 promises to bring exciting new features and improvements that will reshape how we build web applications.

## Server Components Revolution

React Server Components are becoming mainstream, offering unprecedented performance benefits by allowing components to run on the server. This hybrid approach reduces bundle sizes and improves initial page load times significantly.

\`\`\`jsx
// Server Component example
async function BlogPost({ id }) {
  const post = await fetch(\`/api/posts/\${id}\`);
  return <article>{post.content}</article>;
}
\`\`\`

## Concurrent Features

The concurrent features in React 18 are being refined and expanded. Features like automatic batching, startTransition, and Suspense for data fetching are becoming more robust and easier to use.

## Better Developer Experience

- Improved error boundaries
- Enhanced debugging tools
- Better TypeScript integration
- Streamlined testing utilities

## Performance Optimizations

React's performance continues to improve with better tree-shaking, reduced bundle sizes, and smarter re-rendering algorithms.

The future of React looks incredibly promising, and developers should prepare for these exciting changes coming in 2025.`,
    excerpt: 'Exploring the exciting new features and improvements coming to React in 2025, including Server Components and enhanced performance.',
    author: 'Sarah Chen',
    authorAvatar: 'https://images.pexels.com/photos/1239291/pexels-photo-1239291.jpeg?w=150&h=150&fit=crop&crop=face',
    publishedAt: '2024-12-15T10:30:00.000Z',
    readingTime: 5,
    tags: ['React', 'Frontend', 'JavaScript', 'Web Development'],
    coverImage: 'https://images.pexels.com/photos/1181673/pexels-photo-1181673.jpeg?w=800&h=400&fit=crop',
    claps: 42,
  },
  {
    id: '2',
    title: 'Building Scalable APIs with Node.js and TypeScript',
    content: `# Building Scalable APIs with Node.js and TypeScript

Creating robust, maintainable APIs is crucial for modern web applications. This guide covers best practices for building scalable APIs using Node.js and TypeScript.

## Why TypeScript for APIs?

TypeScript brings type safety to your API development, catching errors at compile time and improving code maintainability.

\`\`\`typescript
interface User {
  id: string;
  email: string;
  name: string;
  createdAt: Date;
}

interface CreateUserRequest {
  email: string;
  name: string;
  password: string;
}
\`\`\`

## Architecture Patterns

### Clean Architecture
Organizing your code into layers:
- **Controllers**: Handle HTTP requests and responses
- **Services**: Contain business logic
- **Repositories**: Handle data access
- **Entities**: Define your domain models

### Dependency Injection
Use dependency injection to make your code more testable and maintainable.

## Error Handling

Implement consistent error handling across your API:

\`\`\`typescript
class ApiError extends Error {
  statusCode: number;
  
  constructor(message: string, statusCode: number = 500) {
    super(message);
    this.statusCode = statusCode;
  }
}
\`\`\`

## Testing Strategies

- Unit tests for business logic
- Integration tests for API endpoints
- End-to-end tests for critical user flows

Building scalable APIs requires careful planning and adherence to best practices. TypeScript adds an extra layer of reliability that pays dividends as your application grows.`,
    excerpt: 'Learn how to build robust, maintainable APIs using Node.js and TypeScript with clean architecture patterns.',
    author: 'Marcus Rodriguez',
    authorAvatar: 'https://images.pexels.com/photos/220453/pexels-photo-220453.jpeg?w=150&h=150&fit=crop&crop=face',
    publishedAt: '2024-12-14T14:22:00.000Z',
    readingTime: 8,
    tags: ['Node.js', 'TypeScript', 'API', 'Backend'],
    coverImage: 'https://images.pexels.com/photos/1181244/pexels-photo-1181244.jpeg?w=800&h=400&fit=crop',
    claps: 38,
  },
  {
    id: '3',
    title: 'UX Design Principles for Better Web Applications',
    content: `# UX Design Principles for Better Web Applications

Creating intuitive and engaging web applications requires a deep understanding of user experience principles. Here are the key concepts every developer should know.

## User-Centered Design

Always start with your users. Understand their needs, goals, and pain points through:
- User research
- Personas
- User journey mapping
- Usability testing

## The Principle of Least Effort

Users will always choose the path that requires the least cognitive and physical effort. Design your interfaces to minimize friction.

## Visual Hierarchy

Guide users' attention using:
- **Size**: Larger elements draw more attention
- **Color**: Use contrast to highlight important elements
- **Spacing**: White space creates focus
- **Typography**: Different font weights and sizes create hierarchy

## Consistency is Key

Maintain consistency in:
- Navigation patterns
- Visual styling
- Interaction patterns
- Content structure

## Feedback and Affordances

Provide clear feedback for all user actions:
- Loading states
- Success/error messages
- Visual changes on interaction
- Clear call-to-action buttons

## Mobile-First Approach

Design for mobile devices first, then scale up:
- Touch-friendly interfaces
- Readable text sizes
- Appropriate spacing
- Fast loading times

## Accessibility

Ensure your applications are usable by everyone:
- Semantic HTML
- Proper color contrast
- Keyboard navigation
- Screen reader compatibility

Good UX design is invisible - when done right, users can accomplish their goals without thinking about the interface. Focus on solving real problems and removing friction from the user experience.`,
    excerpt: 'Essential UX design principles that every web developer should understand to create better user experiences.',
    author: 'Emma Thompson',
    authorAvatar: 'https://images.pexels.com/photos/1181519/pexels-photo-1181519.jpeg?w=150&h=150&fit=crop&crop=face',
    publishedAt: '2024-12-13T09:15:00.000Z',
    readingTime: 6,
    tags: ['UX Design', 'Web Design', 'User Experience'],
    coverImage: 'https://images.pexels.com/photos/1181316/pexels-photo-1181316.jpeg?w=800&h=400&fit=crop',
    claps: 55,
  },
  {
    id: '4',
    title: 'Modern CSS: Grid, Flexbox, and Container Queries',
    content: `# Modern CSS: Grid, Flexbox, and Container Queries

CSS has evolved dramatically in recent years. Let's explore the modern layout techniques that are reshaping web design.

## CSS Grid: The Ultimate Layout Tool

CSS Grid provides unprecedented control over 2D layouts:

\`\`\`css
.grid-container {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
  gap: 2rem;
  padding: 2rem;
}
\`\`\`

### Grid Areas
Define named grid areas for semantic layouts:

\`\`\`css
.layout {
  display: grid;
  grid-template-areas: 
    "header header header"
    "sidebar main aside"
    "footer footer footer";
  grid-template-columns: 200px 1fr 200px;
}
\`\`\`

## Flexbox: Perfect for 1D Layouts

Flexbox excels at distributing space along a single axis:

\`\`\`css
.flex-container {
  display: flex;
  justify-content: space-between;
  align-items: center;
  gap: 1rem;
}
\`\`\`

## Container Queries: Responsive Components

Container queries allow components to respond to their container's size:

\`\`\`css
.card {
  container-type: inline-size;
}

@container (min-width: 400px) {
  .card-content {
    display: flex;
    gap: 1rem;
  }
}
\`\`\`

## Logical Properties

Use logical properties for better internationalization:

\`\`\`css
.element {
  margin-inline: auto;
  padding-block: 1rem;
  border-inline-start: 2px solid blue;
}
\`\`\`

## Custom Properties (CSS Variables)

Dynamic styling with custom properties:

\`\`\`css
:root {
  --primary-color: #3b82f6;
  --spacing-unit: 1rem;
}

.button {
  background: var(--primary-color);
  padding: var(--spacing-unit);
}
\`\`\`

These modern CSS features provide powerful tools for creating responsive, maintainable layouts. Embrace these techniques to build better web experiences.`,
    excerpt: 'Master modern CSS layout techniques including Grid, Flexbox, and the revolutionary Container Queries.',
    author: 'Sarah Chen',
    authorAvatar: 'https://images.pexels.com/photos/1239291/pexels-photo-1239291.jpeg?w=150&h=150&fit=crop&crop=face',
    publishedAt: '2024-12-12T16:45:00.000Z',
    readingTime: 7,
    tags: ['CSS', 'Web Design', 'Responsive Design'],
    coverImage: 'https://images.pexels.com/photos/1181354/pexels-photo-1181354.jpeg?w=800&h=400&fit=crop',
    claps: 29,
  },
];