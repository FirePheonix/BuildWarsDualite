export interface Article {
  id: string;
  title: string;
  content: string;
  excerpt: string;
  author: string;
  authorAvatar: string;
  publishedAt: string;
  readingTime: number;
  tags: string[];
  coverImage?: string;
  claps: number;
}

export interface Author {
  name: string;
  bio: string;
  avatar: string;
  followersCount: number;
  articlesCount: number;
}