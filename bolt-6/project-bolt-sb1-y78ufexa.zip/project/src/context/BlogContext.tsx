import React, { createContext, useContext, useState, useEffect } from 'react';
import { Article, Author } from '../types/blog';
import { mockArticles, mockAuthors } from '../data/mockData';

interface BlogContextType {
  articles: Article[];
  authors: Author[];
  searchTerm: string;
  selectedTag: string;
  setSearchTerm: (term: string) => void;
  setSelectedTag: (tag: string) => void;
  addArticle: (article: Omit<Article, 'id' | 'publishedAt' | 'claps'>) => void;
  updateArticle: (id: string, article: Omit<Article, 'id' | 'publishedAt' | 'claps'>) => void;
  getArticleById: (id: string) => Article | undefined;
  getArticlesByAuthor: (author: string) => Article[];
  incrementClaps: (id: string) => void;
}

const BlogContext = createContext<BlogContextType | undefined>(undefined);

export const useBlog = () => {
  const context = useContext(BlogContext);
  if (!context) {
    throw new Error('useBlog must be used within a BlogProvider');
  }
  return context;
};

export const BlogProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [articles, setArticles] = useState<Article[]>([]);
  const [authors] = useState<Author[]>(mockAuthors);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedTag, setSelectedTag] = useState('');

  useEffect(() => {
    const savedArticles = localStorage.getItem('blogArticles');
    if (savedArticles) {
      setArticles(JSON.parse(savedArticles));
    } else {
      setArticles(mockArticles);
    }
  }, []);

  useEffect(() => {
    localStorage.setItem('blogArticles', JSON.stringify(articles));
  }, [articles]);

  const addArticle = (articleData: Omit<Article, 'id' | 'publishedAt' | 'claps'>) => {
    const newArticle: Article = {
      ...articleData,
      id: Date.now().toString(),
      publishedAt: new Date().toISOString(),
      claps: 0,
    };
    setArticles(prev => [newArticle, ...prev]);
  };

  const updateArticle = (id: string, articleData: Omit<Article, 'id' | 'publishedAt' | 'claps'>) => {
    setArticles(prev =>
      prev.map(article =>
        article.id === id
          ? { ...article, ...articleData }
          : article
      )
    );
  };

  const getArticleById = (id: string) => {
    return articles.find(article => article.id === id);
  };

  const getArticlesByAuthor = (author: string) => {
    return articles.filter(article => article.author === author);
  };

  const incrementClaps = (id: string) => {
    setArticles(prev =>
      prev.map(article =>
        article.id === id
          ? { ...article, claps: article.claps + 1 }
          : article
      )
    );
  };

  return (
    <BlogContext.Provider
      value={{
        articles,
        authors,
        searchTerm,
        selectedTag,
        setSearchTerm,
        setSelectedTag,
        addArticle,
        updateArticle,
        getArticleById,
        getArticlesByAuthor,
        incrementClaps,
      }}
    >
      {children}
    </BlogContext.Provider>
  );
};