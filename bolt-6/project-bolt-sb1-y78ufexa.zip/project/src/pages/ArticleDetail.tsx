import React, { useEffect, useState } from 'react';
import { useParams, Link, useNavigate } from 'react-router-dom';
import { formatDistanceToNow } from 'date-fns';
import ReactMarkdown from 'react-markdown';
import remarkGfm from 'remark-gfm';
import { Clock, Heart, Edit3, ArrowLeft } from 'lucide-react';
import { useBlog } from '../context/BlogContext';

export const ArticleDetail: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const { getArticleById, incrementClaps } = useBlog();
  const [hasClapped, setHasClapped] = useState(false);
  const navigate = useNavigate();

  const article = id ? getArticleById(id) : undefined;

  useEffect(() => {
    const clappedArticles = JSON.parse(localStorage.getItem('clappedArticles') || '[]');
    setHasClapped(clappedArticles.includes(id));
  }, [id]);

  if (!article) {
    return (
      <div className="max-w-4xl mx-auto px-4 py-12 text-center">
        <h1 className="text-2xl font-bold text-gray-900 mb-4">Article Not Found</h1>
        <p className="text-gray-600 mb-6">The article you're looking for doesn't exist.</p>
        <Link
          to="/"
          className="inline-flex items-center space-x-2 text-emerald-600 hover:text-emerald-700"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>Back to Home</span>
        </Link>
      </div>
    );
  }

  const handleClap = () => {
    if (!hasClapped) {
      incrementClaps(article.id);
      setHasClapped(true);
      
      const clappedArticles = JSON.parse(localStorage.getItem('clappedArticles') || '[]');
      clappedArticles.push(article.id);
      localStorage.setItem('clappedArticles', JSON.stringify(clappedArticles));
    }
  };

  return (
    <article className="max-w-4xl mx-auto px-4 py-8">
      {/* Back Button */}
      <button
        onClick={() => navigate(-1)}
        className="inline-flex items-center space-x-2 text-emerald-600 hover:text-emerald-700 mb-6"
      >
        <ArrowLeft className="w-4 h-4" />
        <span>Back</span>
      </button>

      {/* Cover Image */}
      {article.coverImage && (
        <div className="aspect-video mb-8 rounded-xl overflow-hidden">
          <img
            src={article.coverImage}
            alt={article.title}
            className="w-full h-full object-cover"
          />
        </div>
      )}

      {/* Article Header */}
      <header className="mb-8">
        <h1 className="text-4xl md:text-5xl font-bold text-gray-900 mb-6 leading-tight">
          {article.title}
        </h1>

        <div className="flex items-center justify-between flex-wrap gap-4">
          <div className="flex items-center space-x-4">
            <img
              src={article.authorAvatar}
              alt={article.author}
              className="w-12 h-12 rounded-full object-cover"
            />
            <div>
              <Link
                to={`/profile/${article.author}`}
                className="text-lg font-medium text-gray-900 hover:text-emerald-600 transition-colors"
              >
                {article.author}
              </Link>
              <div className="flex items-center text-sm text-gray-500 space-x-2">
                <span>{formatDistanceToNow(new Date(article.publishedAt), { addSuffix: true })}</span>
                <span>•</span>
                <div className="flex items-center space-x-1">
                  <Clock className="w-4 h-4" />
                  <span>{article.readingTime} min read</span>
                </div>
              </div>
            </div>
          </div>

          <div className="flex items-center space-x-4">
            <button
              onClick={handleClap}
              disabled={hasClapped}
              className={`flex items-center space-x-2 px-4 py-2 rounded-full transition-all ${
                hasClapped
                  ? 'bg-pink-100 text-pink-700 cursor-not-allowed'
                  : 'bg-gray-100 text-gray-700 hover:bg-pink-100 hover:text-pink-700'
              }`}
            >
              <Heart className={`w-4 h-4 ${hasClapped ? 'fill-current' : ''}`} />
              <span>{article.claps}</span>
            </button>

            <Link
              to={`/edit/${article.id}`}
              className="flex items-center space-x-2 px-4 py-2 text-emerald-600 bg-emerald-50 rounded-full hover:bg-emerald-100 transition-colors"
            >
              <Edit3 className="w-4 h-4" />
              <span>Edit</span>
            </Link>
          </div>
        </div>
      </header>

      {/* Article Content */}
      <div className="prose prose-lg max-w-none">
        <ReactMarkdown
          remarkPlugins={[remarkGfm]}
          components={{
            h1: ({ children }) => (
              <h1 className="text-3xl font-bold text-gray-900 mb-4 mt-8">{children}</h1>
            ),
            h2: ({ children }) => (
              <h2 className="text-2xl font-bold text-gray-900 mb-3 mt-6">{children}</h2>
            ),
            h3: ({ children }) => (
              <h3 className="text-xl font-bold text-gray-900 mb-2 mt-4">{children}</h3>
            ),
            p: ({ children }) => (
              <p className="text-gray-700 leading-relaxed mb-4">{children}</p>
            ),
            code: ({ children }) => (
              <code className="bg-gray-100 px-2 py-1 rounded text-sm font-mono text-gray-800">
                {children}
              </code>
            ),
            pre: ({ children }) => (
              <pre className="bg-gray-900 text-gray-100 p-4 rounded-lg overflow-x-auto mb-4">
                {children}
              </pre>
            ),
            blockquote: ({ children }) => (
              <blockquote className="border-l-4 border-emerald-500 pl-4 italic text-gray-600 mb-4">
                {children}
              </blockquote>
            ),
            ul: ({ children }) => (
              <ul className="list-disc list-inside mb-4 text-gray-700 space-y-1">
                {children}
              </ul>
            ),
            ol: ({ children }) => (
              <ol className="list-decimal list-inside mb-4 text-gray-700 space-y-1">
                {children}
              </ol>
            ),
          }}
        >
          {article.content}
        </ReactMarkdown>
      </div>

      {/* Tags */}
      <div className="mt-8 pt-8 border-t border-gray-200">
        <div className="flex flex-wrap gap-2">
          {article.tags.map((tag) => (
            <span
              key={tag}
              className="inline-block px-4 py-2 text-sm font-medium text-emerald-700 bg-emerald-50 rounded-full hover:bg-emerald-100 transition-colors cursor-pointer"
            >
              {tag}
            </span>
          ))}
        </div>
      </div>
    </article>
  );
};