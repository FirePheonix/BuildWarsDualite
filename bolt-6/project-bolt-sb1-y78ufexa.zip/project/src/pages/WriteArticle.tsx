import React, { useState, useEffect } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import ReactMarkdown from 'react-markdown';
import remarkGfm from 'remark-gfm';
import { Eye, FileText, Save, X } from 'lucide-react';
import { useBlog } from '../context/BlogContext';

export const WriteArticle: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const { addArticle, updateArticle, getArticleById } = useBlog();
  const navigate = useNavigate();
  const isEditing = !!id;

  const [title, setTitle] = useState('');
  const [content, setContent] = useState('');
  const [excerpt, setExcerpt] = useState('');
  const [tags, setTags] = useState('');
  const [coverImage, setCoverImage] = useState('');
  const [isPreview, setIsPreview] = useState(false);

  useEffect(() => {
    if (isEditing && id) {
      const article = getArticleById(id);
      if (article) {
        setTitle(article.title);
        setContent(article.content);
        setExcerpt(article.excerpt);
        setTags(article.tags.join(', '));
        setCoverImage(article.coverImage || '');
      }
    }
  }, [isEditing, id, getArticleById]);

  const calculateReadingTime = (text: string): number => {
    const wordsPerMinute = 200;
    const wordCount = text.split(/\s+/).length;
    return Math.ceil(wordCount / wordsPerMinute);
  };

  const handleSave = () => {
    if (!title.trim() || !content.trim()) {
      alert('Please fill in the title and content');
      return;
    }

    const articleData = {
      title: title.trim(),
      content: content.trim(),
      excerpt: excerpt.trim() || content.slice(0, 200) + '...',
      author: 'Sarah Chen', // In a real app, this would come from auth context
      authorAvatar: 'https://images.pexels.com/photos/1239291/pexels-photo-1239291.jpeg?w=150&h=150&fit=crop&crop=face',
      readingTime: calculateReadingTime(content),
      tags: tags.split(',').map(tag => tag.trim()).filter(tag => tag),
      coverImage: coverImage.trim() || undefined,
    };

    if (isEditing && id) {
      updateArticle(id, articleData);
      navigate(`/article/${id}`);
    } else {
      addArticle(articleData);
      navigate('/');
    }
  };

  return (
    <div className="max-w-6xl mx-auto px-4 py-8">
      {/* Header */}
      <div className="flex items-center justify-between mb-8">
        <h1 className="text-3xl font-bold text-gray-900">
          {isEditing ? 'Edit Article' : 'Write New Article'}
        </h1>
        
        <div className="flex items-center space-x-4">
          <button
            onClick={() => setIsPreview(!isPreview)}
            className={`flex items-center space-x-2 px-4 py-2 rounded-lg transition-colors ${
              isPreview
                ? 'bg-emerald-600 text-white'
                : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
            }`}
          >
            {isPreview ? <FileText className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
            <span>{isPreview ? 'Edit' : 'Preview'}</span>
          </button>
          
          <button
            onClick={handleSave}
            className="flex items-center space-x-2 bg-emerald-600 text-white px-6 py-2 rounded-lg hover:bg-emerald-700 transition-colors"
          >
            <Save className="w-4 h-4" />
            <span>{isEditing ? 'Update' : 'Publish'}</span>
          </button>
          
          <button
            onClick={() => navigate('/')}
            className="p-2 text-gray-500 hover:text-gray-700 transition-colors"
          >
            <X className="w-6 h-6" />
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* Editor */}
        <div className={`space-y-6 ${isPreview ? 'hidden lg:block' : ''}`}>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Title
            </label>
            <input
              type="text"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder="Enter your article title..."
              className="w-full px-4 py-3 text-xl border border-gray-300 rounded-lg focus:ring-2 focus:ring-emerald-500 focus:border-transparent"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Cover Image URL (optional)
            </label>
            <input
              type="url"
              value={coverImage}
              onChange={(e) => setCoverImage(e.target.value)}
              placeholder="https://example.com/image.jpg"
              className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-emerald-500 focus:border-transparent"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Excerpt (optional)
            </label>
            <textarea
              value={excerpt}
              onChange={(e) => setExcerpt(e.target.value)}
              placeholder="Brief description of your article..."
              rows={3}
              className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-emerald-500 focus:border-transparent resize-none"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Tags (comma-separated)
            </label>
            <input
              type="text"
              value={tags}
              onChange={(e) => setTags(e.target.value)}
              placeholder="React, JavaScript, Web Development"
              className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-emerald-500 focus:border-transparent"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Content (Markdown)
            </label>
            <textarea
              value={content}
              onChange={(e) => setContent(e.target.value)}
              placeholder="Write your article in Markdown..."
              rows={20}
              className="w-full px-4 py-3 font-mono text-sm border border-gray-300 rounded-lg focus:ring-2 focus:ring-emerald-500 focus:border-transparent resize-none"
            />
          </div>
        </div>

        {/* Preview */}
        <div className={`lg:sticky lg:top-24 lg:max-h-screen lg:overflow-y-auto ${!isPreview ? 'hidden lg:block' : ''}`}>
          <div className="bg-white rounded-lg border border-gray-200 p-6">
            <h2 className="text-lg font-semibold text-gray-900 mb-4">Preview</h2>
            
            {coverImage && (
              <div className="aspect-video mb-6 rounded-lg overflow-hidden">
                <img
                  src={coverImage}
                  alt="Cover"
                  className="w-full h-full object-cover"
                  onError={(e) => {
                    e.currentTarget.style.display = 'none';
                  }}
                />
              </div>
            )}
            
            <h1 className="text-3xl font-bold text-gray-900 mb-4">
              {title || 'Your Article Title'}
            </h1>
            
            {excerpt && (
              <p className="text-lg text-gray-600 mb-6 italic">
                {excerpt}
              </p>
            )}
            
            {tags && (
              <div className="flex flex-wrap gap-2 mb-6">
                {tags.split(',').map((tag, index) => (
                  <span
                    key={index}
                    className="px-3 py-1 text-sm bg-emerald-50 text-emerald-700 rounded-full"
                  >
                    {tag.trim()}
                  </span>
                ))}
              </div>
            )}
            
            <div className="prose prose-lg max-w-none">
              <ReactMarkdown remarkPlugins={[remarkGfm]}>
                {content || 'Start writing your article content...'}
              </ReactMarkdown>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};