import React from 'react';
import { useParams } from 'react-router-dom';
import { Users, FileText, Calendar } from 'lucide-react';
import { ArticleCard } from '../components/ArticleCard';
import { useBlog } from '../context/BlogContext';
import { mockAuthors } from '../data/mockData';

export const Profile: React.FC = () => {
  const { author } = useParams<{ author: string }>();
  const { getArticlesByAuthor } = useBlog();

  const authorData = mockAuthors.find(a => a.name === author);
  const articles = author ? getArticlesByAuthor(author) : [];

  if (!authorData) {
    return (
      <div className="max-w-4xl mx-auto px-4 py-12 text-center">
        <h1 className="text-2xl font-bold text-gray-900 mb-4">Author Not Found</h1>
        <p className="text-gray-600">The author you're looking for doesn't exist.</p>
      </div>
    );
  }

  return (
    <div className="max-w-6xl mx-auto px-4 py-8">
      {/* Profile Header */}
      <div className="bg-white rounded-lg shadow-sm p-8 mb-8">
        <div className="flex items-start space-x-6">
          <img
            src={authorData.avatar}
            alt={authorData.name}
            className="w-24 h-24 rounded-full object-cover"
          />
          
          <div className="flex-1">
            <h1 className="text-3xl font-bold text-gray-900 mb-2">
              {authorData.name}
            </h1>
            
            <p className="text-lg text-gray-600 mb-4 leading-relaxed">
              {authorData.bio}
            </p>
            
            <div className="flex items-center space-x-6 text-sm text-gray-500">
              <div className="flex items-center space-x-1">
                <Users className="w-4 h-4" />
                <span>{authorData.followersCount} followers</span>
              </div>
              
              <div className="flex items-center space-x-1">
                <FileText className="w-4 h-4" />
                <span>{articles.length} articles</span>
              </div>
              
              <div className="flex items-center space-x-1">
                <Calendar className="w-4 h-4" />
                <span>Member since 2023</span>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Articles Section */}
      <div className="mb-6">
        <h2 className="text-2xl font-bold text-gray-900 mb-2">
          Articles by {authorData.name}
        </h2>
        <p className="text-gray-600">
          {articles.length} article{articles.length !== 1 ? 's' : ''} published
        </p>
      </div>

      {articles.length === 0 ? (
        <div className="bg-white rounded-lg shadow-sm p-12 text-center">
          <FileText className="w-12 h-12 text-gray-400 mx-auto mb-4" />
          <h3 className="text-lg font-medium text-gray-900 mb-2">
            No articles yet
          </h3>
          <p className="text-gray-500">
            {authorData.name} hasn't published any articles yet.
          </p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {articles.map((article) => (
            <ArticleCard key={article.id} article={article} />
          ))}
        </div>
      )}
    </div>
  );
};