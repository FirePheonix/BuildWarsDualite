import React, { useMemo } from 'react';
import { ArticleCard } from '../components/ArticleCard';
import { TagFilter } from '../components/TagFilter';
import { useBlog } from '../context/BlogContext';

export const Home: React.FC = () => {
  const { articles, searchTerm, selectedTag } = useBlog();

  const filteredArticles = useMemo(() => {
    return articles.filter(article => {
      const matchesSearch = searchTerm === '' || 
        article.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
        article.content.toLowerCase().includes(searchTerm.toLowerCase()) ||
        article.author.toLowerCase().includes(searchTerm.toLowerCase());
      
      const matchesTag = selectedTag === '' || article.tags.includes(selectedTag);
      
      return matchesSearch && matchesTag;
    });
  }, [articles, searchTerm, selectedTag]);

  return (
    <main className="max-w-7xl mx-auto px-4 py-8">
      <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
        {/* Main Content */}
        <div className="lg:col-span-3">
          {searchTerm && (
            <div className="mb-6">
              <h2 className="text-2xl font-bold text-gray-900">
                Search Results for "{searchTerm}"
              </h2>
              <p className="text-gray-600 mt-1">
                {filteredArticles.length} article{filteredArticles.length !== 1 ? 's' : ''} found
              </p>
            </div>
          )}
          
          {selectedTag && !searchTerm && (
            <div className="mb-6">
              <h2 className="text-2xl font-bold text-gray-900">
                Articles tagged "{selectedTag}"
              </h2>
              <p className="text-gray-600 mt-1">
                {filteredArticles.length} article{filteredArticles.length !== 1 ? 's' : ''} found
              </p>
            </div>
          )}

          {!searchTerm && !selectedTag && (
            <div className="mb-8">
              <h1 className="text-4xl font-bold text-gray-900 mb-2">
                Welcome to BlogSpace
              </h1>
              <p className="text-xl text-gray-600">
                Discover stories, thinking, and expertise from writers on any topic.
              </p>
            </div>
          )}

          {filteredArticles.length === 0 ? (
            <div className="text-center py-12">
              <h3 className="text-lg font-medium text-gray-900 mb-2">
                No articles found
              </h3>
              <p className="text-gray-500">
                Try adjusting your search or filter criteria.
              </p>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {filteredArticles.map((article) => (
                <ArticleCard key={article.id} article={article} />
              ))}
            </div>
          )}
        </div>

        {/* Sidebar */}
        <aside className="lg:col-span-1">
          <TagFilter />
        </aside>
      </div>
    </main>
  );
};