import React from 'react';
import { Link } from 'react-router-dom';
import { formatDistanceToNow } from 'date-fns';
import { Clock, Heart } from 'lucide-react';
import { Article } from '../types/blog';

interface ArticleCardProps {
  article: Article;
}

export const ArticleCard: React.FC<ArticleCardProps> = ({ article }) => {
  return (
    <article className="bg-white rounded-lg shadow-sm hover:shadow-md transition-shadow duration-300 overflow-hidden group">
      {article.coverImage && (
        <div className="aspect-video overflow-hidden">
          <img
            src={article.coverImage}
            alt={article.title}
            className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
          />
        </div>
      )}
      
      <div className="p-6">
        <div className="flex items-center space-x-3 mb-4">
          <img
            src={article.authorAvatar}
            alt={article.author}
            className="w-10 h-10 rounded-full object-cover"
          />
          <div className="flex-1 min-w-0">
            <Link
              to={`/profile/${article.author}`}
              className="text-sm font-medium text-gray-900 hover:text-emerald-600 transition-colors"
            >
              {article.author}
            </Link>
            <div className="flex items-center text-xs text-gray-500 space-x-2">
              <span>{formatDistanceToNow(new Date(article.publishedAt), { addSuffix: true })}</span>
              <span>•</span>
              <div className="flex items-center space-x-1">
                <Clock className="w-3 h-3" />
                <span>{article.readingTime} min read</span>
              </div>
            </div>
          </div>
        </div>

        <Link to={`/article/${article.id}`} className="group">
          <h2 className="text-xl font-bold text-gray-900 group-hover:text-emerald-600 transition-colors mb-2 line-clamp-2">
            {article.title}
          </h2>
          <p className="text-gray-600 mb-4 line-clamp-3 leading-relaxed">
            {article.excerpt}
          </p>
        </Link>

        <div className="flex items-center justify-between">
          <div className="flex flex-wrap gap-2">
            {article.tags.slice(0, 3).map((tag) => (
              <span
                key={tag}
                className="inline-block px-3 py-1 text-xs font-medium text-emerald-700 bg-emerald-50 rounded-full hover:bg-emerald-100 transition-colors cursor-pointer"
              >
                {tag}
              </span>
            ))}
          </div>
          
          <div className="flex items-center space-x-1 text-gray-500">
            <Heart className="w-4 h-4" />
            <span className="text-sm">{article.claps}</span>
          </div>
        </div>
      </div>
    </article>
  );
};