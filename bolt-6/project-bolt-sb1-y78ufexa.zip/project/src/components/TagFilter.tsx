import React from 'react';
import { useBlog } from '../context/BlogContext';

export const TagFilter: React.FC = () => {
  const { articles, selectedTag, setSelectedTag } = useBlog();

  // Get all unique tags
  const allTags = Array.from(
    new Set(articles.flatMap(article => article.tags))
  ).sort();

  return (
    <div className="bg-white rounded-lg shadow-sm p-6 sticky top-24">
      <h3 className="text-lg font-semibold text-gray-900 mb-4">Topics</h3>
      
      <div className="space-y-2">
        <button
          onClick={() => setSelectedTag('')}
          className={`w-full text-left px-3 py-2 rounded-md text-sm transition-colors ${
            selectedTag === ''
              ? 'bg-emerald-100 text-emerald-700 font-medium'
              : 'text-gray-600 hover:bg-gray-50'
          }`}
        >
          All Topics
        </button>
        
        {allTags.map((tag) => {
          const count = articles.filter(article => article.tags.includes(tag)).length;
          return (
            <button
              key={tag}
              onClick={() => setSelectedTag(tag)}
              className={`w-full text-left px-3 py-2 rounded-md text-sm transition-colors flex justify-between items-center ${
                selectedTag === tag
                  ? 'bg-emerald-100 text-emerald-700 font-medium'
                  : 'text-gray-600 hover:bg-gray-50'
              }`}
            >
              <span>{tag}</span>
              <span className="text-xs text-gray-400">{count}</span>
            </button>
          );
        })}
      </div>
    </div>
  );
};