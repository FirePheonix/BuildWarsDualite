import React, { useState } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { Search, PenTool, User, Menu, X } from 'lucide-react';
import { useBlog } from '../context/BlogContext';

export const Header: React.FC = () => {
  const { searchTerm, setSearchTerm } = useBlog();
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const location = useLocation();

  const isHomePage = location.pathname === '/';

  return (
    <header className="bg-white shadow-sm sticky top-0 z-50">
      <div className="max-w-6xl mx-auto px-4 py-3">
        <div className="flex items-center justify-between">
          {/* Logo */}
          <Link to="/" className="flex items-center space-x-2">
            <PenTool className="w-8 h-8 text-emerald-600" />
            <span className="text-2xl font-bold text-gray-900">BlogSpace</span>
          </Link>

          {/* Search Bar - Desktop */}
          {isHomePage && (
            <div className="hidden md:flex flex-1 max-w-md mx-8">
              <div className="relative w-full">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                <input
                  type="text"
                  placeholder="Search articles..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="w-full pl-10 pr-4 py-2 border border-gray-200 rounded-full focus:outline-none focus:ring-2 focus:ring-emerald-500 focus:border-transparent"
                />
              </div>
            </div>
          )}

          {/* Desktop Navigation */}
          <nav className="hidden md:flex items-center space-x-6">
            <Link
              to="/write"
              className="flex items-center space-x-2 px-4 py-2 text-emerald-600 hover:text-emerald-700 transition-colors"
            >
              <PenTool className="w-4 h-4" />
              <span>Write</span>
            </Link>
            <Link
              to="/profile/Sarah Chen"
              className="flex items-center space-x-2 px-4 py-2 text-gray-600 hover:text-gray-800 transition-colors"
            >
              <User className="w-4 h-4" />
              <span>Profile</span>
            </Link>
          </nav>

          {/* Mobile Menu Button */}
          <button
            onClick={() => setIsMenuOpen(!isMenuOpen)}
            className="md:hidden p-2 text-gray-600 hover:text-gray-800 transition-colors"
          >
            {isMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>

        {/* Mobile Search */}
        {isHomePage && (
          <div className="md:hidden mt-4">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
              <input
                type="text"
                placeholder="Search articles..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full pl-10 pr-4 py-2 border border-gray-200 rounded-full focus:outline-none focus:ring-2 focus:ring-emerald-500 focus:border-transparent"
              />
            </div>
          </div>
        )}

        {/* Mobile Menu */}
        {isMenuOpen && (
          <div className="md:hidden mt-4 py-4 border-t border-gray-200">
            <nav className="space-y-4">
              <Link
                to="/write"
                className="flex items-center space-x-2 px-4 py-2 text-emerald-600 hover:text-emerald-700 transition-colors"
                onClick={() => setIsMenuOpen(false)}
              >
                <PenTool className="w-4 h-4" />
                <span>Write Article</span>
              </Link>
              <Link
                to="/profile/Sarah Chen"
                className="flex items-center space-x-2 px-4 py-2 text-gray-600 hover:text-gray-800 transition-colors"
                onClick={() => setIsMenuOpen(false)}
              >
                <User className="w-4 h-4" />
                <span>My Profile</span>
              </Link>
            </nav>
          </div>
        )}
      </div>
    </header>
  );
};