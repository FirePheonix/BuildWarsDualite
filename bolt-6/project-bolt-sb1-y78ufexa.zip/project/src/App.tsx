import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { Header } from './components/Header';
import { Home } from './pages/Home';
import { ArticleDetail } from './pages/ArticleDetail';
import { WriteArticle } from './pages/WriteArticle';
import { Profile } from './pages/Profile';
import { BlogProvider } from './context/BlogContext';

function App() {
  return (
    <BlogProvider>
      <Router>
        <div className="min-h-screen bg-gray-50">
          <Header />
          <Routes>
            <Route path="/" element={<Home />} />
            <Route path="/article/:id" element={<ArticleDetail />} />
            <Route path="/write" element={<WriteArticle />} />
            <Route path="/edit/:id" element={<WriteArticle />} />
            <Route path="/profile/:author" element={<Profile />} />
          </Routes>
        </div>
      </Router>
    </BlogProvider>
  );
}

export default App;