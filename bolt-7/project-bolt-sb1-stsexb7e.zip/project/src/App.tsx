import React, { useState } from 'react';
import { Navigation } from './components/Navigation';
import { Dashboard } from './components/Dashboard';
import { CourseList } from './components/CourseList';
import { CreateCourse } from './components/CreateCourse';
import { Certificates } from './components/Certificates';
import { StudentProgress } from './components/StudentProgress';

function App() {
  const [activeTab, setActiveTab] = useState('dashboard');
  const [userRole, setUserRole] = useState<'instructor' | 'student'>('student');

  const renderContent = () => {
    switch (activeTab) {
      case 'dashboard':
        return <Dashboard userRole={userRole} />;
      case 'courses':
        if (userRole === 'instructor') {
          return <CourseList userRole={userRole} viewType="created" />;
        }
        return <CourseList userRole={userRole} viewType="enrolled" />;
      case 'catalog':
        return <CourseList userRole={userRole} viewType="catalog" />;
      case 'create':
        return <CreateCourse />;
      case 'certificates':
        return <Certificates />;
      case 'students':
        return <StudentProgress />;
      default:
        return <Dashboard userRole={userRole} />;
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <Navigation 
        activeTab={activeTab} 
        setActiveTab={setActiveTab} 
        userRole={userRole}
      />
      
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Role Switcher (for demo purposes) */}
        <div className="mb-6">
          <div className="flex items-center space-x-4">
            <span className="text-sm font-medium text-gray-700">Switch Role:</span>
            <button
              onClick={() => setUserRole('student')}
              className={`px-3 py-1 text-sm rounded-md transition-colors ${
                userRole === 'student'
                  ? 'bg-blue-600 text-white'
                  : 'bg-gray-200 text-gray-700 hover:bg-gray-300'
              }`}
            >
              Student
            </button>
            <button
              onClick={() => setUserRole('instructor')}
              className={`px-3 py-1 text-sm rounded-md transition-colors ${
                userRole === 'instructor'
                  ? 'bg-blue-600 text-white'
                  : 'bg-gray-200 text-gray-700 hover:bg-gray-300'
              }`}
            >
              Instructor
            </button>
          </div>
        </div>
        
        {renderContent()}
      </main>
    </div>
  );
}

export default App;