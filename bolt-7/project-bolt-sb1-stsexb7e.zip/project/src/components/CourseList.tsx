import React from 'react';
import { Star, Clock, Users, BookOpen } from 'lucide-react';
import { Course } from '../types';
import { mockCourses } from '../data/mockData';

interface CourseListProps {
  userRole: 'instructor' | 'student';
  viewType?: 'enrolled' | 'catalog' | 'created';
}

export const CourseList: React.FC<CourseListProps> = ({ userRole, viewType = 'catalog' }) => {
  let courses = mockCourses;
  let title = 'All Courses';

  if (viewType === 'enrolled' && userRole === 'student') {
    title = 'My Enrolled Courses';
    courses = mockCourses.filter(course => ['1', '3'].includes(course.id));
  } else if (viewType === 'created' && userRole === 'instructor') {
    title = 'My Courses';
  }

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-3xl font-bold text-gray-900">{title}</h2>
        {viewType === 'catalog' && (
          <div className="flex space-x-4">
            <select className="px-4 py-2 border border-gray-300 rounded-md focus:ring-blue-500 focus:border-blue-500">
              <option>All Categories</option>
              <option>Web Development</option>
              <option>Data Science</option>
              <option>Marketing</option>
            </select>
            <select className="px-4 py-2 border border-gray-300 rounded-md focus:ring-blue-500 focus:border-blue-500">
              <option>All Levels</option>
              <option>Beginner</option>
              <option>Intermediate</option>
              <option>Advanced</option>
            </select>
          </div>
        )}
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {courses.map((course) => (
          <CourseCard key={course.id} course={course} userRole={userRole} viewType={viewType} />
        ))}
      </div>
    </div>
  );
};

interface CourseCardProps {
  course: Course;
  userRole: 'instructor' | 'student';
  viewType?: 'enrolled' | 'catalog' | 'created';
}

const CourseCard: React.FC<CourseCardProps> = ({ course, userRole, viewType }) => {
  const isEnrolled = viewType === 'enrolled';
  const isOwned = viewType === 'created';

  const getLevelColor = (level: string) => {
    switch (level) {
      case 'Beginner': return 'bg-green-100 text-green-800';
      case 'Intermediate': return 'bg-yellow-100 text-yellow-800';
      case 'Advanced': return 'bg-red-100 text-red-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  return (
    <div className="bg-white rounded-xl shadow-md overflow-hidden hover:shadow-lg transition-shadow duration-300">
      <div className="relative">
        <img
          src={course.thumbnail}
          alt={course.title}
          className="w-full h-48 object-cover"
        />
        <div className="absolute top-4 left-4">
          <span className={`px-2 py-1 rounded-full text-xs font-medium ${getLevelColor(course.level)}`}>
            {course.level}
          </span>
        </div>
        <div className="absolute top-4 right-4">
          <div className="flex items-center bg-white rounded-full px-2 py-1">
            <Star className="h-4 w-4 text-yellow-400 mr-1" />
            <span className="text-sm font-medium">{course.rating}</span>
          </div>
        </div>
      </div>

      <div className="p-6">
        <div className="mb-2">
          <span className="text-sm text-blue-600 font-medium">{course.category}</span>
        </div>
        
        <h3 className="text-xl font-semibold text-gray-900 mb-2 line-clamp-2">
          {course.title}
        </h3>
        
        <p className="text-gray-600 text-sm mb-4 line-clamp-2">
          {course.description}
        </p>
        
        <div className="flex items-center text-sm text-gray-500 mb-4 space-x-4">
          <div className="flex items-center">
            <Clock className="h-4 w-4 mr-1" />
            {course.duration}
          </div>
          <div className="flex items-center">
            <Users className="h-4 w-4 mr-1" />
            {course.enrolledStudents}
          </div>
          <div className="flex items-center">
            <BookOpen className="h-4 w-4 mr-1" />
            {course.lessons.length} lessons
          </div>
        </div>

        <div className="flex items-center justify-between">
          <div>
            <p className="text-sm text-gray-600">by {course.instructor}</p>
            {!isEnrolled && !isOwned && (
              <p className="text-2xl font-bold text-gray-900">${course.price}</p>
            )}
          </div>
          
          <div className="flex space-x-2">
            {isEnrolled ? (
              <button className="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 transition-colors">
                Continue
              </button>
            ) : isOwned ? (
              <button className="px-4 py-2 bg-green-600 text-white rounded-md hover:bg-green-700 transition-colors">
                Manage
              </button>
            ) : (
              <button className="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 transition-colors">
                Enroll Now
              </button>
            )}
          </div>
        </div>

        {isEnrolled && (
          <div className="mt-4">
            <div className="flex justify-between text-sm text-gray-600 mb-1">
              <span>Progress</span>
              <span>67%</span>
            </div>
            <div className="w-full bg-gray-200 rounded-full h-2">
              <div className="bg-blue-600 h-2 rounded-full" style={{ width: '67%' }}></div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};