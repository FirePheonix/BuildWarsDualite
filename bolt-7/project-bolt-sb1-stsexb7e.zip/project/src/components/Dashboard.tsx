import React from 'react';
import { BookOpen, Users, Award, TrendingUp, Clock, Star } from 'lucide-react';
import { mockCourses, mockStudent, mockProgress } from '../data/mockData';

interface DashboardProps {
  userRole: 'instructor' | 'student';
}

export const Dashboard: React.FC<DashboardProps> = ({ userRole }) => {
  if (userRole === 'instructor') {
    return <InstructorDashboard />;
  }
  return <StudentDashboard />;
};

const InstructorDashboard: React.FC = () => {
  const totalCourses = mockCourses.length;
  const totalStudents = mockCourses.reduce((sum, course) => sum + course.enrolledStudents, 0);
  const avgRating = mockCourses.reduce((sum, course) => sum + course.rating, 0) / mockCourses.length;

  return (
    <div className="space-y-6">
      <h2 className="text-3xl font-bold text-gray-900">Instructor Dashboard</h2>
      
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <div className="bg-white rounded-lg shadow p-6">
          <div className="flex items-center">
            <BookOpen className="h-12 w-12 text-blue-600" />
            <div className="ml-4">
              <p className="text-2xl font-semibold text-gray-900">{totalCourses}</p>
              <p className="text-gray-600">Total Courses</p>
            </div>
          </div>
        </div>
        
        <div className="bg-white rounded-lg shadow p-6">
          <div className="flex items-center">
            <Users className="h-12 w-12 text-green-600" />
            <div className="ml-4">
              <p className="text-2xl font-semibold text-gray-900">{totalStudents}</p>
              <p className="text-gray-600">Total Students</p>
            </div>
          </div>
        </div>
        
        <div className="bg-white rounded-lg shadow p-6">
          <div className="flex items-center">
            <Star className="h-12 w-12 text-yellow-500" />
            <div className="ml-4">
              <p className="text-2xl font-semibold text-gray-900">{avgRating.toFixed(1)}</p>
              <p className="text-gray-600">Average Rating</p>
            </div>
          </div>
        </div>
        
        <div className="bg-white rounded-lg shadow p-6">
          <div className="flex items-center">
            <TrendingUp className="h-12 w-12 text-indigo-600" />
            <div className="ml-4">
              <p className="text-2xl font-semibold text-gray-900">$2,847</p>
              <p className="text-gray-600">Monthly Revenue</p>
            </div>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-white rounded-lg shadow p-6">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Recent Course Activity</h3>
          <div className="space-y-4">
            {mockCourses.slice(0, 3).map((course) => (
              <div key={course.id} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                <div>
                  <p className="font-medium text-gray-900">{course.title}</p>
                  <p className="text-sm text-gray-600">{course.enrolledStudents} enrolled students</p>
                </div>
                <div className="flex items-center">
                  <Star className="h-4 w-4 text-yellow-400 mr-1" />
                  <span className="text-sm text-gray-700">{course.rating}</span>
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className="bg-white rounded-lg shadow p-6">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Top Performing Courses</h3>
          <div className="space-y-4">
            {mockCourses
              .sort((a, b) => b.enrolledStudents - a.enrolledStudents)
              .slice(0, 3)
              .map((course, index) => (
              <div key={course.id} className="flex items-center p-3 bg-gray-50 rounded-lg">
                <div className="flex-shrink-0 w-8 h-8 bg-blue-600 rounded-full flex items-center justify-center text-white font-semibold text-sm mr-3">
                  {index + 1}
                </div>
                <div className="flex-1">
                  <p className="font-medium text-gray-900">{course.title}</p>
                  <p className="text-sm text-gray-600">{course.enrolledStudents} students</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

const StudentDashboard: React.FC = () => {
  const enrolledCourses = mockCourses.filter(course => 
    mockStudent.enrolledCourses.includes(course.id)
  );
  const completedCourses = mockStudent.completedCourses.length;
  const totalHours = enrolledCourses.reduce((sum, course) => 
    sum + parseInt(course.duration), 0
  );

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-3xl font-bold text-gray-900">Welcome back, Alex!</h2>
        <div className="text-right">
          <p className="text-sm text-gray-600">Overall Progress</p>
          <p className="text-2xl font-bold text-blue-600">{mockStudent.totalProgress}%</p>
        </div>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="bg-white rounded-lg shadow p-6">
          <div className="flex items-center">
            <BookOpen className="h-12 w-12 text-blue-600" />
            <div className="ml-4">
              <p className="text-2xl font-semibold text-gray-900">{enrolledCourses.length}</p>
              <p className="text-gray-600">Enrolled Courses</p>
            </div>
          </div>
        </div>
        
        <div className="bg-white rounded-lg shadow p-6">
          <div className="flex items-center">
            <Award className="h-12 w-12 text-green-600" />
            <div className="ml-4">
              <p className="text-2xl font-semibold text-gray-900">{completedCourses}</p>
              <p className="text-gray-600">Completed</p>
            </div>
          </div>
        </div>
        
        <div className="bg-white rounded-lg shadow p-6">
          <div className="flex items-center">
            <Clock className="h-12 w-12 text-indigo-600" />
            <div className="ml-4">
              <p className="text-2xl font-semibold text-gray-900">{totalHours}h</p>
              <p className="text-gray-600">Learning Hours</p>
            </div>
          </div>
        </div>
      </div>

      <div className="bg-white rounded-lg shadow p-6">
        <h3 className="text-lg font-semibold text-gray-900 mb-4">Continue Learning</h3>
        <div className="space-y-4">
          {enrolledCourses.map((course) => {
            const progress = mockProgress.find(p => p.courseId === course.id);
            return (
              <div key={course.id} className="flex items-center p-4 border border-gray-200 rounded-lg hover:border-blue-300 transition-colors">
                <img
                  src={course.thumbnail}
                  alt={course.title}
                  className="w-16 h-16 rounded-lg object-cover mr-4"
                />
                <div className="flex-1">
                  <h4 className="font-semibold text-gray-900">{course.title}</h4>
                  <p className="text-sm text-gray-600 mb-2">by {course.instructor}</p>
                  {progress && (
                    <div className="w-full bg-gray-200 rounded-full h-2">
                      <div 
                        className="bg-blue-600 h-2 rounded-full transition-all duration-300"
                        style={{ width: `${progress.progressPercentage}%` }}
                      ></div>
                    </div>
                  )}
                </div>
                <div className="text-right">
                  {progress && (
                    <p className="text-sm font-medium text-blue-600">
                      {progress.progressPercentage}% complete
                    </p>
                  )}
                  <button className="mt-2 px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 transition-colors">
                    Continue
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};