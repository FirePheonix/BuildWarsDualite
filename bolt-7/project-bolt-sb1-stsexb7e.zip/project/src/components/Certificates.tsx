import React from 'react';
import { Award, Download, Calendar, User } from 'lucide-react';
import { mockCertificates } from '../data/mockData';

export const Certificates: React.FC = () => {
  return (
    <div className="space-y-6">
      <h2 className="text-3xl font-bold text-gray-900">My Certificates</h2>
      
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {mockCertificates.map((certificate) => (
          <CertificateCard key={certificate.id} certificate={certificate} />
        ))}
        
        {/* Sample Certificate Design */}
        <div className="bg-gradient-to-br from-blue-50 to-indigo-100 rounded-lg p-8 border-2 border-dashed border-blue-300">
          <div className="text-center">
            <Award className="h-12 w-12 text-blue-600 mx-auto mb-4" />
            <h3 className="text-lg font-semibold text-gray-900 mb-2">Complete more courses</h3>
            <p className="text-gray-600">Earn certificates by completing your enrolled courses</p>
          </div>
        </div>
      </div>

      {/* Certificate Preview Modal (would be implemented with state management) */}
      <CertificatePreview />
    </div>
  );
};

interface CertificateCardProps {
  certificate: any;
}

const CertificateCard: React.FC<CertificateCardProps> = ({ certificate }) => {
  return (
    <div className="bg-white rounded-lg shadow-md overflow-hidden hover:shadow-lg transition-shadow">
      <div className="bg-gradient-to-r from-blue-600 to-indigo-600 p-6">
        <div className="flex items-center justify-between text-white">
          <Award className="h-8 w-8" />
          <span className="text-sm font-medium">Certificate</span>
        </div>
      </div>
      
      <div className="p-6">
        <h3 className="text-xl font-semibold text-gray-900 mb-2">
          {certificate.courseName}
        </h3>
        
        <div className="space-y-3 text-sm text-gray-600 mb-6">
          <div className="flex items-center">
            <User className="h-4 w-4 mr-2" />
            <span>Issued to {certificate.studentName}</span>
          </div>
          <div className="flex items-center">
            <Calendar className="h-4 w-4 mr-2" />
            <span>Completed on {certificate.completionDate.toLocaleDateString()}</span>
          </div>
          <div className="flex items-center">
            <User className="h-4 w-4 mr-2" />
            <span>Instructor: {certificate.instructor}</span>
          </div>
        </div>
        
        <div className="flex space-x-3">
          <button className="flex-1 px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 transition-colors">
            View Certificate
          </button>
          <button className="px-4 py-2 border border-gray-300 text-gray-700 rounded-md hover:bg-gray-50 transition-colors">
            <Download className="h-4 w-4" />
          </button>
        </div>
      </div>
    </div>
  );
};

const CertificatePreview: React.FC = () => {
  return (
    <div className="bg-white rounded-lg shadow-lg p-8 max-w-4xl mx-auto">
      <div className="border-8 border-blue-600 rounded-lg p-8 bg-gradient-to-br from-blue-50 to-white">
        <div className="text-center">
          <div className="mb-6">
            <Award className="h-16 w-16 text-blue-600 mx-auto mb-4" />
            <h1 className="text-3xl font-bold text-gray-900 mb-2">Certificate of Completion</h1>
            <p className="text-gray-600">This is to certify that</p>
          </div>
          
          <div className="mb-8">
            <h2 className="text-4xl font-bold text-blue-600 mb-4">Alex Thompson</h2>
            <p className="text-lg text-gray-700 mb-2">has successfully completed the course</p>
            <h3 className="text-2xl font-semibold text-gray-900 mb-4">Digital Marketing Mastery</h3>
            <p className="text-gray-600">on December 18, 2024</p>
          </div>
          
          <div className="flex justify-between items-end">
            <div className="text-left">
              <div className="border-t-2 border-gray-300 pt-2">
                <p className="font-semibold">Emma Rodriguez</p>
                <p className="text-sm text-gray-600">Course Instructor</p>
              </div>
            </div>
            
            <div className="text-center">
              <div className="w-20 h-20 bg-blue-600 rounded-full flex items-center justify-center mb-2">
                <Award className="h-10 w-10 text-white" />
              </div>
              <p className="text-xs text-gray-500">EduPlatform Seal</p>
            </div>
            
            <div className="text-right">
              <div className="border-t-2 border-gray-300 pt-2">
                <p className="font-semibold">EduPlatform</p>
                <p className="text-sm text-gray-600">Learning Platform</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};