import { Course, Student, Certificate, Progress } from '../types';

export const mockCourses: Course[] = [
  {
    id: '1',
    title: 'Complete Web Development Bootcamp',
    description: 'Learn HTML, CSS, JavaScript, React, Node.js, and more in this comprehensive web development course.',
    instructor: 'Sarah Johnson',
    duration: '40 hours',
    level: 'Beginner',
    category: 'Web Development',
    thumbnail: 'https://images.pexels.com/photos/270348/pexels-photo-270348.jpeg',
    lessons: [
      { id: '1', title: 'Introduction to HTML', description: 'Learn the basics of HTML', duration: '45 min', content: 'HTML content here', completed: true, order: 1 },
      { id: '2', title: 'CSS Fundamentals', description: 'Master CSS styling', duration: '60 min', content: 'CSS content here', completed: true, order: 2 },
      { id: '3', title: 'JavaScript Basics', description: 'Programming with JavaScript', duration: '90 min', content: 'JS content here', completed: false, order: 3 },
    ],
    enrolledStudents: 1247,
    rating: 4.8,
    price: 99,
    createdAt: new Date('2024-01-15'),
  },
  {
    id: '2',
    title: 'Data Science with Python',
    description: 'Master data analysis, visualization, and machine learning using Python and popular libraries.',
    instructor: 'Dr. Michael Chen',
    duration: '35 hours',
    level: 'Intermediate',
    category: 'Data Science',
    thumbnail: 'https://images.pexels.com/photos/546819/pexels-photo-546819.jpeg',
    lessons: [
      { id: '4', title: 'Python Fundamentals', description: 'Python basics for data science', duration: '50 min', content: 'Python content', completed: false, order: 1 },
      { id: '5', title: 'Data Analysis with Pandas', description: 'Working with data using Pandas', duration: '75 min', content: 'Pandas content', completed: false, order: 2 },
    ],
    enrolledStudents: 892,
    rating: 4.9,
    price: 129,
    createdAt: new Date('2024-02-01'),
  },
  {
    id: '3',
    title: 'Digital Marketing Mastery',
    description: 'Learn SEO, social media marketing, content marketing, and paid advertising strategies.',
    instructor: 'Emma Rodriguez',
    duration: '25 hours',
    level: 'Beginner',
    category: 'Marketing',
    thumbnail: 'https://images.pexels.com/photos/265087/pexels-photo-265087.jpeg',
    lessons: [
      { id: '6', title: 'SEO Fundamentals', description: 'Search engine optimization basics', duration: '60 min', content: 'SEO content', completed: true, order: 1 },
    ],
    enrolledStudents: 2156,
    rating: 4.7,
    price: 79,
    createdAt: new Date('2024-01-20'),
  },
];

export const mockStudent: Student = {
  id: 'student-1',
  name: 'Alex Thompson',
  email: 'alex.thompson@email.com',
  avatar: 'https://images.pexels.com/photos/614810/pexels-photo-614810.jpeg',
  enrolledCourses: ['1', '3'],
  completedCourses: ['3'],
  certificates: [],
  totalProgress: 67,
};

export const mockProgress: Progress[] = [
  {
    courseId: '1',
    studentId: 'student-1',
    completedLessons: ['1', '2'],
    totalLessons: 3,
    progressPercentage: 67,
    lastAccessed: new Date('2024-12-20'),
  },
  {
    courseId: '3',
    studentId: 'student-1',
    completedLessons: ['6'],
    totalLessons: 1,
    progressPercentage: 100,
    lastAccessed: new Date('2024-12-18'),
  },
];

export const mockCertificates: Certificate[] = [
  {
    id: 'cert-1',
    courseId: '3',
    courseName: 'Digital Marketing Mastery',
    studentName: 'Alex Thompson',
    completionDate: new Date('2024-12-18'),
    instructor: 'Emma Rodriguez',
    certificateUrl: '#',
  },
];