export interface Course {
  id: string;
  title: string;
  description: string;
  instructor: string;
  duration: string;
  level: 'Beginner' | 'Intermediate' | 'Advanced';
  category: string;
  thumbnail: string;
  lessons: Lesson[];
  enrolledStudents: number;
  rating: number;
  price: number;
  createdAt: Date;
}

export interface Lesson {
  id: string;
  title: string;
  description: string;
  duration: string;
  videoUrl?: string;
  content: string;
  completed: boolean;
  order: number;
}

export interface Student {
  id: string;
  name: string;
  email: string;
  avatar: string;
  enrolledCourses: string[];
  completedCourses: string[];
  certificates: Certificate[];
  totalProgress: number;
}

export interface Certificate {
  id: string;
  courseId: string;
  courseName: string;
  studentName: string;
  completionDate: Date;
  instructor: string;
  certificateUrl: string;
}

export interface Progress {
  courseId: string;
  studentId: string;
  completedLessons: string[];
  totalLessons: number;
  progressPercentage: number;
  lastAccessed: Date;
}