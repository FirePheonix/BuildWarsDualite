import React, { useState } from 'react';
import { 
  ArrowLeft, 
  Clock, 
  DollarSign, 
  MapPin, 
  Star, 
  Users, 
  Calendar,
  Flag,
  Heart
} from 'lucide-react';
import { useApp } from '../context/AppContext';
import { Job } from '../types';

interface JobDetailProps {
  job: Job;
  setCurrentView: (view: string) => void;
}

export default function JobDetail({ job, setCurrentView }: JobDetailProps) {
  const { currentUser, addProposal } = useApp();
  const [showProposalForm, setShowProposalForm] = useState(false);
  const [proposal, setProposal] = useState({
    coverLetter: '',
    proposedRate: job.budget.min,
    proposedDuration: job.duration
  });

  const handleSubmitProposal = (e: React.FormEvent) => {
    e.preventDefault();
    if (currentUser && currentUser.type === 'freelancer') {
      addProposal({
        jobId: job.id,
        freelancerId: currentUser.id,
        freelancer: currentUser,
        ...proposal,
        status: 'pending'
      });
      setShowProposalForm(false);
      alert('Proposal submitted successfully!');
    }
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'long',
      day: 'numeric'
    });
  };

  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Back Button */}
        <button
          onClick={() => setCurrentView('find-work')}
          className="flex items-center space-x-2 text-blue-600 hover:text-blue-700 mb-6"
        >
          <ArrowLeft className="h-5 w-5" />
          <span>Back to jobs</span>
        </button>

        <div className="grid lg:grid-cols-3 gap-8">
          {/* Main Content */}
          <div className="lg:col-span-2">
            <div className="bg-white rounded-xl shadow-sm p-8">
              {/* Header */}
              <div className="mb-6">
                <h1 className="text-3xl font-bold text-gray-900 mb-4">{job.title}</h1>
                <div className="flex flex-wrap items-center gap-4 text-gray-600">
                  <div className="flex items-center space-x-1">
                    <Calendar className="h-4 w-4" />
                    <span>Posted {formatDate(job.postedAt)}</span>
                  </div>
                  <div className="flex items-center space-x-1">
                    <Users className="h-4 w-4" />
                    <span>{job.applicants} proposals</span>
                  </div>
                  {job.location && (
                    <div className="flex items-center space-x-1">
                      <MapPin className="h-4 w-4" />
                      <span>{job.location}</span>
                    </div>
                  )}
                </div>
              </div>

              {/* Budget */}
              <div className="mb-8 p-4 bg-blue-50 rounded-lg">
                <div className="flex items-center justify-between">
                  <div>
                    <h3 className="font-semibold text-gray-900 mb-1">Budget</h3>
                    <div className="text-2xl font-bold text-blue-600">
                      ${job.budget.min} - ${job.budget.max}
                    </div>
                    <span className="text-sm text-gray-600 capitalize">
                      {job.budget.type} rate • {job.duration} • {job.experienceLevel} level
                    </span>
                  </div>
                  <div className="text-right">
                    <div className="text-sm text-gray-600">Category</div>
                    <div className="font-semibold text-gray-900">{job.category}</div>
                  </div>
                </div>
              </div>

              {/* Description */}
              <div className="mb-8">
                <h3 className="text-xl font-semibold text-gray-900 mb-4">Job Description</h3>
                <div className="prose prose-gray max-w-none">
                  <p className="text-gray-700 leading-relaxed whitespace-pre-line">{job.description}</p>
                </div>
              </div>

              {/* Skills */}
              <div className="mb-8">
                <h3 className="text-xl font-semibold text-gray-900 mb-4">Required Skills</h3>
                <div className="flex flex-wrap gap-2">
                  {job.skills.map((skill, index) => (
                    <span
                      key={index}
                      className="bg-gray-100 text-gray-700 px-4 py-2 rounded-lg text-sm font-medium"
                    >
                      {skill}
                    </span>
                  ))}
                </div>
              </div>

              {/* Proposal Form */}
              {showProposalForm && currentUser?.type === 'freelancer' && (
                <div className="mb-8">
                  <h3 className="text-xl font-semibold text-gray-900 mb-4">Submit Proposal</h3>
                  <form onSubmit={handleSubmitProposal} className="space-y-6">
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">
                        Cover Letter
                      </label>
                      <textarea
                        value={proposal.coverLetter}
                        onChange={(e) => setProposal({...proposal, coverLetter: e.target.value})}
                        rows={6}
                        className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                        placeholder="Explain why you're the perfect fit for this job..."
                        required
                      />
                    </div>
                    
                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-2">
                          Proposed Rate ($)
                        </label>
                        <input
                          type="number"
                          value={proposal.proposedRate}
                          onChange={(e) => setProposal({...proposal, proposedRate: Number(e.target.value)})}
                          className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                          min="1"
                          required
                        />
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-2">
                          Duration
                        </label>
                        <input
                          type="text"
                          value={proposal.proposedDuration}
                          onChange={(e) => setProposal({...proposal, proposedDuration: e.target.value})}
                          className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                          placeholder="e.g., 2-3 weeks"
                          required
                        />
                      </div>
                    </div>

                    <div className="flex space-x-4">
                      <button
                        type="submit"
                        className="bg-blue-600 text-white px-6 py-3 rounded-lg font-semibold hover:bg-blue-700 transition-colors"
                      >
                        Submit Proposal
                      </button>
                      <button
                        type="button"
                        onClick={() => setShowProposalForm(false)}
                        className="bg-gray-200 text-gray-700 px-6 py-3 rounded-lg font-semibold hover:bg-gray-300 transition-colors"
                      >
                        Cancel
                      </button>
                    </div>
                  </form>
                </div>
              )}
            </div>
          </div>

          {/* Sidebar */}
          <div className="lg:col-span-1">
            {/* Apply Section */}
            <div className="bg-white rounded-xl shadow-sm p-6 mb-6">
              {currentUser?.type === 'freelancer' ? (
                <>
                  <button
                    onClick={() => setShowProposalForm(!showProposalForm)}
                    className="w-full bg-blue-600 text-white py-3 rounded-lg font-semibold hover:bg-blue-700 transition-colors mb-3"
                  >
                    {showProposalForm ? 'Hide Proposal Form' : 'Apply for this Job'}
                  </button>
                  <div className="flex space-x-2">
                    <button className="flex-1 border border-gray-300 py-2 rounded-lg hover:bg-gray-50 transition-colors flex items-center justify-center space-x-1">
                      <Heart className="h-4 w-4" />
                      <span className="text-sm">Save</span>
                    </button>
                    <button className="flex-1 border border-gray-300 py-2 rounded-lg hover:bg-gray-50 transition-colors flex items-center justify-center space-x-1">
                      <Flag className="h-4 w-4" />
                      <span className="text-sm">Report</span>
                    </button>
                  </div>
                </>
              ) : (
                <div className="text-center text-gray-600">
                  <p className="mb-2">Switch to freelancer mode to apply for jobs</p>
                </div>
              )}
            </div>

            {/* Client Info */}
            <div className="bg-white rounded-xl shadow-sm p-6">
              <h3 className="text-lg font-semibold text-gray-900 mb-4">About the Client</h3>
              <div className="flex items-center space-x-3 mb-4">
                <img
                  src={job.postedBy.avatar}
                  alt={job.postedBy.name}
                  className="h-16 w-16 rounded-full object-cover"
                />
                <div>
                  <h4 className="font-semibold text-gray-900">{job.postedBy.name}</h4>
                  <div className="flex items-center space-x-1 mb-1">
                    <Star className="h-4 w-4 text-yellow-400 fill-current" />
                    <span className="text-sm text-gray-600">{job.postedBy.rating} rating</span>
                  </div>
                  <span className="text-sm text-gray-500">{job.postedBy.totalJobs} jobs posted</span>
                </div>
              </div>
              
              <div className="space-y-3 text-sm">
                <div className="flex justify-between">
                  <span className="text-gray-600">Payment verified</span>
                  <span className="text-green-600 font-medium">Yes</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">Avg response time</span>
                  <span className="text-gray-900">2 hours</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">Job success</span>
                  <span className="text-green-600 font-medium">95%</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}