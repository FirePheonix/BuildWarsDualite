import React, { useState } from 'react';
import { 
  Star, 
  MapPin, 
  Calendar, 
  Edit3, 
  Save, 
  X,
  Briefcase,
  DollarSign,
  Clock,
  Award
} from 'lucide-react';
import { useApp } from '../context/AppContext';

interface ProfileProps {
  setCurrentView: (view: string) => void;
}

export default function Profile({ setCurrentView }: ProfileProps) {
  const { currentUser, setCurrentUser } = useApp();
  const [isEditing, setIsEditing] = useState(false);
  const [editData, setEditData] = useState({
    name: currentUser?.name || '',
    bio: currentUser?.bio || '',
    location: currentUser?.location || '',
    hourlyRate: currentUser?.hourlyRate || 0,
    skills: currentUser?.skills?.join(', ') || ''
  });

  if (!currentUser) return null;

  const handleSave = () => {
    setCurrentUser({
      ...currentUser,
      name: editData.name,
      bio: editData.bio,
      location: editData.location,
      hourlyRate: editData.hourlyRate,
      skills: editData.skills.split(',').map(s => s.trim()).filter(s => s)
    });
    setIsEditing(false);
  };

  const handleCancel = () => {
    setEditData({
      name: currentUser.name,
      bio: currentUser.bio || '',
      location: currentUser.location || '',
      hourlyRate: currentUser.hourlyRate || 0,
      skills: currentUser.skills?.join(', ') || ''
    });
    setIsEditing(false);
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'long'
    });
  };

  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Profile Header */}
        <div className="bg-white rounded-xl shadow-sm p-8 mb-8">
          <div className="flex flex-col lg:flex-row lg:items-start lg:space-x-8">
            {/* Avatar and Basic Info */}
            <div className="flex flex-col sm:flex-row items-center sm:items-start space-y-4 sm:space-y-0 sm:space-x-6 mb-6 lg:mb-0">
              <div className="relative">
                <img
                  src={currentUser.avatar}
                  alt={currentUser.name}
                  className="h-24 w-24 rounded-full object-cover border-4 border-white shadow-lg"
                />
                <div className="absolute -bottom-2 -right-2 bg-green-400 border-4 border-white rounded-full h-8 w-8"></div>
              </div>
              <div className="text-center sm:text-left">
                {isEditing ? (
                  <input
                    type="text"
                    value={editData.name}
                    onChange={(e) => setEditData({...editData, name: e.target.value})}
                    className="text-2xl font-bold text-gray-900 bg-transparent border-b-2 border-blue-500 focus:outline-none mb-2"
                  />
                ) : (
                  <h1 className="text-2xl font-bold text-gray-900 mb-2">{currentUser.name}</h1>
                )}
                <div className="flex items-center justify-center sm:justify-start space-x-1 mb-2">
                  <Star className="h-5 w-5 text-yellow-400 fill-current" />
                  <span className="font-semibold text-gray-900">{currentUser.rating}</span>
                  <span className="text-gray-600">({currentUser.totalJobs} reviews)</span>
                </div>
                <div className="flex items-center justify-center sm:justify-start text-gray-600 mb-2">
                  <MapPin className="h-4 w-4 mr-1" />
                  {isEditing ? (
                    <input
                      type="text"
                      value={editData.location}
                      onChange={(e) => setEditData({...editData, location: e.target.value})}
                      className="bg-transparent border-b border-gray-300 focus:outline-none focus:border-blue-500"
                      placeholder="Enter location"
                    />
                  ) : (
                    <span>{currentUser.location}</span>
                  )}
                </div>
                <div className="flex items-center justify-center sm:justify-start text-gray-600">
                  <Calendar className="h-4 w-4 mr-1" />
                  <span>Member since {formatDate(currentUser.joinDate)}</span>
                </div>
              </div>
            </div>

            {/* Stats */}
            <div className="flex-1 grid grid-cols-2 lg:grid-cols-4 gap-4">
              <div className="text-center p-4 bg-blue-50 rounded-lg">
                <Briefcase className="h-6 w-6 text-blue-600 mx-auto mb-2" />
                <div className="text-2xl font-bold text-gray-900">{currentUser.totalJobs}</div>
                <div className="text-sm text-gray-600">
                  {currentUser.type === 'client' ? 'Jobs Posted' : 'Jobs Completed'}
                </div>
              </div>
              <div className="text-center p-4 bg-emerald-50 rounded-lg">
                <Star className="h-6 w-6 text-emerald-600 mx-auto mb-2" />
                <div className="text-2xl font-bold text-gray-900">{currentUser.rating}</div>
                <div className="text-sm text-gray-600">Average Rating</div>
              </div>
              {currentUser.type === 'freelancer' && (
                <>
                  <div className="text-center p-4 bg-purple-50 rounded-lg">
                    <DollarSign className="h-6 w-6 text-purple-600 mx-auto mb-2" />
                    <div className="text-2xl font-bold text-gray-900">${currentUser.hourlyRate}</div>
                    <div className="text-sm text-gray-600">Hourly Rate</div>
                  </div>
                  <div className="text-center p-4 bg-orange-50 rounded-lg">
                    <Clock className="h-6 w-6 text-orange-600 mx-auto mb-2" />
                    <div className="text-2xl font-bold text-gray-900">95%</div>
                    <div className="text-sm text-gray-600">Success Rate</div>
                  </div>
                </>
              )}
            </div>

            {/* Edit Button */}
            <div className="flex space-x-2">
              {isEditing ? (
                <>
                  <button
                    onClick={handleSave}
                    className="flex items-center space-x-2 bg-green-600 text-white px-4 py-2 rounded-lg hover:bg-green-700 transition-colors"
                  >
                    <Save className="h-4 w-4" />
                    <span>Save</span>
                  </button>
                  <button
                    onClick={handleCancel}
                    className="flex items-center space-x-2 bg-gray-500 text-white px-4 py-2 rounded-lg hover:bg-gray-600 transition-colors"
                  >
                    <X className="h-4 w-4" />
                    <span>Cancel</span>
                  </button>
                </>
              ) : (
                <button
                  onClick={() => setIsEditing(true)}
                  className="flex items-center space-x-2 bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors"
                >
                  <Edit3 className="h-4 w-4" />
                  <span>Edit Profile</span>
                </button>
              )}
            </div>
          </div>
        </div>

        <div className="grid lg:grid-cols-3 gap-8">
          {/* Main Content */}
          <div className="lg:col-span-2 space-y-8">
            {/* About */}
            <div className="bg-white rounded-xl shadow-sm p-6">
              <h2 className="text-xl font-semibold text-gray-900 mb-4">About</h2>
              {isEditing ? (
                <textarea
                  value={editData.bio}
                  onChange={(e) => setEditData({...editData, bio: e.target.value})}
                  rows={4}
                  className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  placeholder="Tell us about yourself..."
                />
              ) : (
                <p className="text-gray-700 leading-relaxed">
                  {currentUser.bio || "No bio available yet."}
                </p>
              )}
            </div>

            {/* Skills */}
            {currentUser.type === 'freelancer' && (
              <div className="bg-white rounded-xl shadow-sm p-6">
                <h2 className="text-xl font-semibold text-gray-900 mb-4">Skills</h2>
                {isEditing ? (
                  <input
                    type="text"
                    value={editData.skills}
                    onChange={(e) => setEditData({...editData, skills: e.target.value})}
                    className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    placeholder="Enter skills separated by commas"
                  />
                ) : (
                  <div className="flex flex-wrap gap-2">
                    {currentUser.skills?.map((skill, index) => (
                      <span
                        key={index}
                        className="bg-blue-100 text-blue-700 px-3 py-1 rounded-full text-sm font-medium"
                      >
                        {skill}
                      </span>
                    )) || <p className="text-gray-500">No skills listed yet.</p>}
                  </div>
                )}
              </div>
            )}

            {/* Portfolio */}
            {currentUser.type === 'freelancer' && (
              <div className="bg-white rounded-xl shadow-sm p-6">
                <h2 className="text-xl font-semibold text-gray-900 mb-4">Portfolio</h2>
                <div className="grid md:grid-cols-2 gap-4">
                  {currentUser.portfolio?.map((item, index) => (
                    <div key={index} className="bg-gray-100 rounded-lg p-4 text-center">
                      <div className="h-32 bg-gray-200 rounded-lg mb-3 flex items-center justify-center">
                        <span className="text-gray-400">Portfolio Item {index + 1}</span>
                      </div>
                      <h3 className="font-medium text-gray-900">Project {index + 1}</h3>
                    </div>
                  )) || (
                    <div className="col-span-2 text-center py-8 text-gray-500">
                      <Award className="h-12 w-12 mx-auto mb-4 text-gray-300" />
                      <p>No portfolio items yet.</p>
                      <p className="text-sm">Add some work samples to showcase your skills.</p>
                    </div>
                  )}
                </div>
              </div>
            )}

            {/* Rate Information */}
            {currentUser.type === 'freelancer' && (
              <div className="bg-white rounded-xl shadow-sm p-6">
                <h2 className="text-xl font-semibold text-gray-900 mb-4">Rate Information</h2>
                <div className="grid md:grid-cols-2 gap-6">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Hourly Rate
                    </label>
                    {isEditing ? (
                      <div className="flex items-center space-x-2">
                        <span className="text-gray-500">$</span>
                        <input
                          type="number"
                          value={editData.hourlyRate}
                          onChange={(e) => setEditData({...editData, hourlyRate: Number(e.target.value)})}
                          className="border border-gray-300 rounded-lg px-3 py-2 focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                          min="1"
                        />
                        <span className="text-gray-500">/hour</span>
                      </div>
                    ) : (
                      <div className="text-2xl font-bold text-gray-900">
                        ${currentUser.hourlyRate}/hour
                      </div>
                    )}
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Availability
                    </label>
                    <div className="text-lg text-green-600 font-medium">Available Now</div>
                  </div>
                </div>
              </div>
            )}
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* Contact Information */}
            <div className="bg-white rounded-xl shadow-sm p-6">
              <h3 className="text-lg font-semibold text-gray-900 mb-4">Contact</h3>
              <div className="space-y-3">
                <div>
                  <label className="text-sm text-gray-600">Email</label>
                  <div className="font-medium text-gray-900">{currentUser.email}</div>
                </div>
                <div>
                  <label className="text-sm text-gray-600">Response Time</label>
                  <div className="font-medium text-gray-900">Within 2 hours</div>
                </div>
                <div>
                  <label className="text-sm text-gray-600">Languages</label>
                  <div className="font-medium text-gray-900">English (Native)</div>
                </div>
              </div>
            </div>

            {/* Quick Actions */}
            <div className="bg-white rounded-xl shadow-sm p-6">
              <h3 className="text-lg font-semibold text-gray-900 mb-4">Quick Actions</h3>
              <div className="space-y-3">
                <button
                  onClick={() => setCurrentView('dashboard')}
                  className="w-full bg-blue-600 text-white py-2 rounded-lg hover:bg-blue-700 transition-colors"
                >
                  View Dashboard
                </button>
                {currentUser.type === 'freelancer' ? (
                  <button
                    onClick={() => setCurrentView('find-work')}
                    className="w-full border border-gray-300 text-gray-700 py-2 rounded-lg hover:bg-gray-50 transition-colors"
                  >
                    Find Work
                  </button>
                ) : (
                  <button
                    onClick={() => setCurrentView('post-job')}
                    className="w-full border border-gray-300 text-gray-700 py-2 rounded-lg hover:bg-gray-50 transition-colors"
                  >
                    Post a Job
                  </button>
                )}
                <button
                  onClick={() => setCurrentView('messages')}
                  className="w-full border border-gray-300 text-gray-700 py-2 rounded-lg hover:bg-gray-50 transition-colors"
                >
                  Messages
                </button>
              </div>
            </div>

            {/* Account Type Badge */}
            <div className="bg-white rounded-xl shadow-sm p-6">
              <div className="text-center">
                <div className={`inline-flex items-center px-4 py-2 rounded-full text-sm font-medium ${
                  currentUser.type === 'client' 
                    ? 'bg-purple-100 text-purple-700' 
                    : 'bg-emerald-100 text-emerald-700'
                }`}>
                  <span className="capitalize">{currentUser.type} Account</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}