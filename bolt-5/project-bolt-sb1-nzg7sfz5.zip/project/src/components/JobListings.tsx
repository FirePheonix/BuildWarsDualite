import React, { useState, useMemo } from 'react';
import { Search, Filter, MapPin, Clock, DollarSign, Star, Eye } from 'lucide-react';
import { useApp } from '../context/AppContext';
import { Job } from '../types';

interface JobListingsProps {
  setCurrentView: (view: string) => void;
  setSelectedJob: (job: Job) => void;
}

export default function JobListings({ setCurrentView, setSelectedJob }: JobListingsProps) {
  const { jobs } = useApp();
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [budgetRange, setBudgetRange] = useState('all');
  const [experienceLevel, setExperienceLevel] = useState('all');
  const [showFilters, setShowFilters] = useState(false);

  const categories = ['all', 'Web Development', 'Design', 'Data Science', 'Writing', 'Marketing'];
  const budgetRanges = [
    { value: 'all', label: 'Any Budget' },
    { value: 'entry', label: 'Under $1,000' },
    { value: 'mid', label: '$1,000 - $5,000' },
    { value: 'high', label: '$5,000+' }
  ];
  const experienceLevels = ['all', 'entry', 'intermediate', 'expert'];

  const filteredJobs = useMemo(() => {
    return jobs.filter(job => {
      const matchesSearch = job.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
                           job.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
                           job.skills.some(skill => skill.toLowerCase().includes(searchTerm.toLowerCase()));
      
      const matchesCategory = selectedCategory === 'all' || job.category === selectedCategory;
      
      const matchesBudget = budgetRange === 'all' || 
        (budgetRange === 'entry' && job.budget.max < 1000) ||
        (budgetRange === 'mid' && job.budget.min >= 1000 && job.budget.max <= 5000) ||
        (budgetRange === 'high' && job.budget.min > 5000);
      
      const matchesExperience = experienceLevel === 'all' || job.experienceLevel === experienceLevel;
      
      return matchesSearch && matchesCategory && matchesBudget && matchesExperience;
    });
  }, [jobs, searchTerm, selectedCategory, budgetRange, experienceLevel]);

  const handleJobClick = (job: Job) => {
    setSelectedJob(job);
    setCurrentView('job-detail');
  };

  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-2">Find Work</h1>
          <p className="text-gray-600">Discover amazing opportunities that match your skills</p>
        </div>

        {/* Search and Filters */}
        <div className="bg-white rounded-xl shadow-sm p-6 mb-8">
          {/* Search Bar */}
          <div className="relative mb-4">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-5 w-5" />
            <input
              type="text"
              placeholder="Search for jobs, skills, or keywords..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            />
          </div>

          {/* Filter Toggle */}
          <div className="flex justify-between items-center">
            <button
              onClick={() => setShowFilters(!showFilters)}
              className="flex items-center space-x-2 text-blue-600 hover:text-blue-700 font-medium"
            >
              <Filter className="h-5 w-5" />
              <span>Filters</span>
            </button>
            <span className="text-gray-500 text-sm">
              {filteredJobs.length} jobs found
            </span>
          </div>

          {/* Filters */}
          {showFilters && (
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mt-4 pt-4 border-t border-gray-200">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Category</label>
                <select
                  value={selectedCategory}
                  onChange={(e) => setSelectedCategory(e.target.value)}
                  className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                >
                  {categories.map(category => (
                    <option key={category} value={category}>
                      {category === 'all' ? 'All Categories' : category}
                    </option>
                  ))}
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Budget Range</label>
                <select
                  value={budgetRange}
                  onChange={(e) => setBudgetRange(e.target.value)}
                  className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                >
                  {budgetRanges.map(range => (
                    <option key={range.value} value={range.value}>{range.label}</option>
                  ))}
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Experience Level</label>
                <select
                  value={experienceLevel}
                  onChange={(e) => setExperienceLevel(e.target.value)}
                  className="w-full border border-gray-300 rounded-lg px-3 py-2 focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                >
                  {experienceLevels.map(level => (
                    <option key={level} value={level}>
                      {level === 'all' ? 'All Levels' : level.charAt(0).toUpperCase() + level.slice(1)}
                    </option>
                  ))}
                </select>
              </div>
            </div>
          )}
        </div>

        {/* Job Listings */}
        <div className="space-y-6">
          {filteredJobs.length === 0 ? (
            <div className="text-center py-12 bg-white rounded-xl">
              <Search className="h-12 w-12 text-gray-400 mx-auto mb-4" />
              <h3 className="text-lg font-medium text-gray-900 mb-2">No jobs found</h3>
              <p className="text-gray-600">Try adjusting your search criteria or filters</p>
            </div>
          ) : (
            filteredJobs.map(job => (
              <div key={job.id} className="bg-white rounded-xl shadow-sm p-6 hover:shadow-md transition-shadow">
                <div className="flex flex-col lg:flex-row lg:items-start lg:justify-between">
                  {/* Job Info */}
                  <div className="flex-1 lg:pr-6">
                    <div className="flex items-start justify-between mb-3">
                      <h3 
                        className="text-xl font-semibold text-gray-900 hover:text-blue-600 cursor-pointer line-clamp-2"
                        onClick={() => handleJobClick(job)}
                      >
                        {job.title}
                      </h3>
                      <span className="text-2xl font-bold text-gray-900 ml-4">
                        ${job.budget.min}-${job.budget.max}
                        <span className="text-sm text-gray-500 font-normal">/{job.budget.type}</span>
                      </span>
                    </div>
                    
                    <p className="text-gray-600 mb-4 line-clamp-3">{job.description}</p>
                    
                    {/* Skills */}
                    <div className="flex flex-wrap gap-2 mb-4">
                      {job.skills.slice(0, 5).map((skill, index) => (
                        <span key={index} className="bg-blue-50 text-blue-700 px-3 py-1 rounded-full text-sm">
                          {skill}
                        </span>
                      ))}
                      {job.skills.length > 5 && (
                        <span className="bg-gray-100 text-gray-600 px-3 py-1 rounded-full text-sm">
                          +{job.skills.length - 5} more
                        </span>
                      )}
                    </div>
                    
                    {/* Meta Info */}
                    <div className="flex flex-wrap items-center gap-4 text-sm text-gray-600">
                      <div className="flex items-center space-x-1">
                        <Clock className="h-4 w-4" />
                        <span>{job.duration}</span>
                      </div>
                      <div className="flex items-center space-x-1">
                        <DollarSign className="h-4 w-4" />
                        <span className="capitalize">{job.experienceLevel}</span>
                      </div>
                      {job.location && (
                        <div className="flex items-center space-x-1">
                          <MapPin className="h-4 w-4" />
                          <span>{job.location}</span>
                        </div>
                      )}
                      <span className="text-gray-400">•</span>
                      <span>{job.applicants} proposals</span>
                    </div>
                  </div>
                  
                  {/* Client Info & Actions */}
                  <div className="mt-4 lg:mt-0 lg:w-64 flex-shrink-0">
                    <div className="flex items-center space-x-3 mb-4">
                      <img
                        src={job.postedBy.avatar}
                        alt={job.postedBy.name}
                        className="h-10 w-10 rounded-full object-cover"
                      />
                      <div>
                        <p className="font-medium text-gray-900">{job.postedBy.name}</p>
                        <div className="flex items-center space-x-1">
                          <Star className="h-4 w-4 text-yellow-400 fill-current" />
                          <span className="text-sm text-gray-600">{job.postedBy.rating}</span>
                          <span className="text-sm text-gray-400">({job.postedBy.totalJobs} jobs)</span>
                        </div>
                      </div>
                    </div>
                    
                    <div className="flex space-x-2">
                      <button
                        onClick={() => handleJobClick(job)}
                        className="flex-1 bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors text-center text-sm font-medium"
                      >
                        Apply Now
                      </button>
                      <button
                        onClick={() => handleJobClick(job)}
                        className="p-2 border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors"
                        title="View Details"
                      >
                        <Eye className="h-4 w-4 text-gray-600" />
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
}