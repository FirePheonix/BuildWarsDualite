import React from 'react';
import { Search, Star, TrendingUp, Users, Shield, Clock } from 'lucide-react';
import { useApp } from '../context/AppContext';

interface HomePageProps {
  setCurrentView: (view: string) => void;
}

export default function HomePage({ setCurrentView }: HomePageProps) {
  const { jobs, currentUser } = useApp();
  const recentJobs = jobs.slice(0, 3);

  const stats = [
    { label: 'Active Jobs', value: '12,000+', icon: TrendingUp },
    { label: 'Freelancers', value: '50,000+', icon: Users },
    { label: 'Projects Completed', value: '100,000+', icon: Star },
    { label: 'Average Response Time', value: '2 hours', icon: Clock },
  ];

  const categories = [
    { name: 'Web Development', jobs: 2847, color: 'bg-blue-500' },
    { name: 'Mobile Development', jobs: 1923, color: 'bg-emerald-500' },
    { name: 'Design', jobs: 3421, color: 'bg-purple-500' },
    { name: 'Data Science', jobs: 1654, color: 'bg-orange-500' },
    { name: 'Writing', jobs: 892, color: 'bg-pink-500' },
    { name: 'Marketing', jobs: 1234, color: 'bg-indigo-500' },
  ];

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Hero Section */}
      <section className="bg-gradient-to-br from-blue-600 to-blue-800 text-white py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h1 className="text-4xl md:text-6xl font-bold mb-6">
            Find the perfect freelance job
          </h1>
          <p className="text-xl md:text-2xl mb-8 text-blue-100 max-w-3xl mx-auto">
            Connect with talented freelancers or discover amazing opportunities. 
            Your next project starts here.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center max-w-md mx-auto">
            {currentUser?.type === 'freelancer' ? (
              <button
                onClick={() => setCurrentView('find-work')}
                className="bg-white text-blue-600 px-8 py-3 rounded-lg font-semibold hover:bg-gray-100 transition-colors flex items-center justify-center space-x-2"
              >
                <Search className="h-5 w-5" />
                <span>Find Work</span>
              </button>
            ) : (
              <button
                onClick={() => setCurrentView('post-job')}
                className="bg-white text-blue-600 px-8 py-3 rounded-lg font-semibold hover:bg-gray-100 transition-colors"
              >
                Post a Job
              </button>
            )}
            <button
              onClick={() => setCurrentView('find-work')}
              className="border-2 border-white text-white px-8 py-3 rounded-lg font-semibold hover:bg-white hover:text-blue-600 transition-colors"
            >
              Browse Jobs
            </button>
          </div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-8">
            {stats.map((stat, index) => {
              const Icon = stat.icon;
              return (
                <div key={index} className="text-center">
                  <div className="bg-blue-50 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                    <Icon className="h-8 w-8 text-blue-600" />
                  </div>
                  <div className="text-3xl font-bold text-gray-900 mb-2">{stat.value}</div>
                  <div className="text-gray-600">{stat.label}</div>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* Categories Section */}
      <section className="py-16 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">Popular Categories</h2>
            <p className="text-gray-600 max-w-2xl mx-auto">
              Explore thousands of job opportunities across various fields
            </p>
          </div>
          <div className="grid grid-cols-2 md:grid-cols-3 gap-6">
            {categories.map((category, index) => (
              <button
                key={index}
                onClick={() => setCurrentView('find-work')}
                className="bg-white p-6 rounded-xl shadow-sm hover:shadow-md transition-shadow text-left group"
              >
                <div className={`w-12 h-12 ${category.color} rounded-lg mb-4 group-hover:scale-110 transition-transform`}></div>
                <h3 className="font-semibold text-gray-900 mb-2">{category.name}</h3>
                <p className="text-gray-600 text-sm">{category.jobs} jobs available</p>
              </button>
            ))}
          </div>
        </div>
      </section>

      {/* Recent Jobs Section */}
      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">Latest Job Opportunities</h2>
            <p className="text-gray-600 max-w-2xl mx-auto">
              Fresh opportunities posted by top clients
            </p>
          </div>
          <div className="grid md:grid-cols-3 gap-6 mb-8">
            {recentJobs.map((job) => (
              <div key={job.id} className="bg-white border border-gray-200 rounded-xl p-6 hover:shadow-lg transition-shadow">
                <div className="flex items-start justify-between mb-4">
                  <div className="flex-1">
                    <h3 className="font-semibold text-gray-900 mb-2 line-clamp-2">{job.title}</h3>
                    <p className="text-gray-600 text-sm mb-3 line-clamp-3">{job.description}</p>
                  </div>
                </div>
                <div className="flex items-center justify-between mb-4">
                  <div className="text-2xl font-bold text-gray-900">
                    ${job.budget.min}-${job.budget.max}
                    <span className="text-sm text-gray-500 font-normal">
                      /{job.budget.type}
                    </span>
                  </div>
                  <span className="text-sm text-gray-500">{job.applicants} proposals</span>
                </div>
                <div className="flex flex-wrap gap-2 mb-4">
                  {job.skills.slice(0, 3).map((skill, index) => (
                    <span key={index} className="bg-gray-100 text-gray-700 px-3 py-1 rounded-full text-xs">
                      {skill}
                    </span>
                  ))}
                </div>
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-2">
                    <img
                      src={job.postedBy.avatar}
                      alt={job.postedBy.name}
                      className="h-6 w-6 rounded-full object-cover"
                    />
                    <span className="text-sm text-gray-600">{job.postedBy.name}</span>
                    <div className="flex items-center space-x-1">
                      <Star className="h-4 w-4 text-yellow-400 fill-current" />
                      <span className="text-sm text-gray-600">{job.postedBy.rating}</span>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
          <div className="text-center">
            <button
              onClick={() => setCurrentView('find-work')}
              className="bg-blue-600 text-white px-8 py-3 rounded-lg font-semibold hover:bg-blue-700 transition-colors"
            >
              View All Jobs
            </button>
          </div>
        </div>
      </section>

      {/* Trust Section */}
      <section className="py-16 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <Shield className="h-16 w-16 text-blue-600 mx-auto mb-4" />
            <h2 className="text-3xl font-bold text-gray-900 mb-4">Work with confidence</h2>
            <p className="text-gray-600 max-w-3xl mx-auto">
              Our platform provides secure payments, dispute resolution, and quality assurance 
              to ensure successful project completion for both clients and freelancers.
            </p>
          </div>
          <div className="grid md:grid-cols-3 gap-8">
            <div className="text-center">
              <div className="bg-emerald-50 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                <Shield className="h-8 w-8 text-emerald-600" />
              </div>
              <h3 className="font-semibold text-gray-900 mb-2">Secure Payments</h3>
              <p className="text-gray-600">
                Milestone-based payments with escrow protection
              </p>
            </div>
            <div className="text-center">
              <div className="bg-purple-50 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                <Star className="h-8 w-8 text-purple-600" />
              </div>
              <h3 className="font-semibold text-gray-900 mb-2">Quality Assurance</h3>
              <p className="text-gray-600">
                Verified profiles and work history reviews
              </p>
            </div>
            <div className="text-center">
              <div className="bg-orange-50 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                <Users className="h-8 w-8 text-orange-600" />
              </div>
              <h3 className="font-semibold text-gray-900 mb-2">24/7 Support</h3>
              <p className="text-gray-600">
                Professional support team ready to help
              </p>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}