import React, { useState } from 'react';
import { AppProvider } from './context/AppContext';
import Header from './components/Header';
import HomePage from './components/HomePage';
import JobListings from './components/JobListings';
import JobDetail from './components/JobDetail';
import PostJob from './components/PostJob';
import Dashboard from './components/Dashboard';
import Messages from './components/Messages';
import Profile from './components/Profile';
import { Job } from './types';

function App() {
  const [currentView, setCurrentView] = useState('home');
  const [selectedJob, setSelectedJob] = useState<Job | null>(null);

  const renderView = () => {
    switch (currentView) {
      case 'home':
        return <HomePage setCurrentView={setCurrentView} />;
      case 'find-work':
        return (
          <JobListings 
            setCurrentView={setCurrentView} 
            setSelectedJob={setSelectedJob} 
          />
        );
      case 'job-detail':
        return selectedJob ? (
          <JobDetail 
            job={selectedJob} 
            setCurrentView={setCurrentView} 
          />
        ) : null;
      case 'post-job':
        return <PostJob setCurrentView={setCurrentView} />;
      case 'dashboard':
        return <Dashboard setCurrentView={setCurrentView} />;
      case 'messages':
        return <Messages />;
      case 'profile':
        return <Profile setCurrentView={setCurrentView} />;
      default:
        return <HomePage setCurrentView={setCurrentView} />;
    }
  };

  return (
    <AppProvider>
      <div className="min-h-screen bg-gray-50">
        {currentView !== 'messages' && (
          <Header currentView={currentView} setCurrentView={setCurrentView} />
        )}
        <main>
          {renderView()}
        </main>
      </div>
    </AppProvider>
  );
}

export default App;