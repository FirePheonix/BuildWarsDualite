export interface Job {
  id: string;
  title: string;
  description: string;
  category: string;
  budget: {
    min: number;
    max: number;
    type: 'hourly' | 'fixed';
  };
  skills: string[];
  duration: string;
  experienceLevel: 'entry' | 'intermediate' | 'expert';
  postedBy: {
    id: string;
    name: string;
    avatar: string;
    rating: number;
    totalJobs: number;
  };
  postedAt: string;
  applicants: number;
  status: 'open' | 'in-progress' | 'completed' | 'closed';
  location?: string;
}

export interface User {
  id: string;
  name: string;
  email: string;
  avatar: string;
  type: 'client' | 'freelancer';
  rating: number;
  totalJobs: number;
  skills?: string[];
  hourlyRate?: number;
  bio?: string;
  portfolio?: string[];
  location?: string;
  joinDate: string;
}

export interface Proposal {
  id: string;
  jobId: string;
  freelancerId: string;
  freelancer: User;
  coverLetter: string;
  proposedRate: number;
  proposedDuration: string;
  submittedAt: string;
  status: 'pending' | 'accepted' | 'rejected' | 'withdrawn';
}

export interface Message {
  id: string;
  senderId: string;
  receiverId: string;
  content: string;
  timestamp: string;
  read: boolean;
}