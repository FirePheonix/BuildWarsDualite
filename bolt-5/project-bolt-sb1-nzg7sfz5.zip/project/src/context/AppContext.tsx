import React, { createContext, useContext, ReactNode } from 'react';
import { Job, User, Proposal } from '../types';
import { mockJobs, mockUsers, mockProposals } from '../data/mockData';
import { useLocalStorage } from '../hooks/useLocalStorage';

interface AppContextType {
  jobs: Job[];
  users: User[];
  proposals: Proposal[];
  currentUser: User | null;
  setCurrentUser: (user: User | null) => void;
  addJob: (job: Omit<Job, 'id' | 'postedAt' | 'applicants'>) => void;
  addProposal: (proposal: Omit<Proposal, 'id' | 'submittedAt'>) => void;
  updateProposal: (proposalId: string, updates: Partial<Proposal>) => void;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

export function AppProvider({ children }: { children: ReactNode }) {
  const [jobs, setJobs] = useLocalStorage<Job[]>('jobs', mockJobs);
  const [users, setUsers] = useLocalStorage<User[]>('users', mockUsers);
  const [proposals, setProposals] = useLocalStorage<Proposal[]>('proposals', mockProposals);
  const [currentUser, setCurrentUser] = useLocalStorage<User | null>('currentUser', mockUsers[0]);

  const addJob = (jobData: Omit<Job, 'id' | 'postedAt' | 'applicants'>) => {
    const newJob: Job = {
      ...jobData,
      id: Date.now().toString(),
      postedAt: new Date().toISOString(),
      applicants: 0
    };
    setJobs([newJob, ...jobs]);
  };

  const addProposal = (proposalData: Omit<Proposal, 'id' | 'submittedAt'>) => {
    const newProposal: Proposal = {
      ...proposalData,
      id: Date.now().toString(),
      submittedAt: new Date().toISOString()
    };
    setProposals([...proposals, newProposal]);
    
    // Update job applicant count
    setJobs(jobs.map(job => 
      job.id === proposalData.jobId 
        ? { ...job, applicants: job.applicants + 1 }
        : job
    ));
  };

  const updateProposal = (proposalId: string, updates: Partial<Proposal>) => {
    setProposals(proposals.map(proposal => 
      proposal.id === proposalId 
        ? { ...proposal, ...updates }
        : proposal
    ));
  };

  return (
    <AppContext.Provider value={{
      jobs,
      users,
      proposals,
      currentUser,
      setCurrentUser,
      addJob,
      addProposal,
      updateProposal
    }}>
      {children}
    </AppContext.Provider>
  );
}

export function useApp() {
  const context = useContext(AppContext);
  if (context === undefined) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return context;
}