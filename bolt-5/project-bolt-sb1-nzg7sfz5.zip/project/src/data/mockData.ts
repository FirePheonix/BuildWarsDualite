import { Job, User, Proposal } from '../types';

export const mockJobs: Job[] = [
  {
    id: '1',
    title: 'Full-Stack React Developer for E-commerce Platform',
    description: 'We are looking for an experienced React developer to build a modern e-commerce platform. The project involves creating a responsive frontend with React/TypeScript, integrating with REST APIs, implementing payment processing, and ensuring optimal performance.',
    category: 'Web Development',
    budget: { min: 5000, max: 8000, type: 'fixed' },
    skills: ['React', 'TypeScript', 'Node.js', 'PostgreSQL', 'Stripe'],
    duration: '2-3 months',
    experienceLevel: 'expert',
    postedBy: {
      id: 'client1',
      name: 'Sarah Johnson',
      avatar: 'https://images.pexels.com/photos/774909/pexels-photo-774909.jpeg?auto=compress&cs=tinysrgb&w=150&h=150&dpr=1',
      rating: 4.8,
      totalJobs: 12
    },
    postedAt: '2024-01-15T10:00:00Z',
    applicants: 24,
    status: 'open',
    location: 'Remote'
  },
  {
    id: '2',
    title: 'Mobile App UI/UX Designer',
    description: 'Design a modern, user-friendly mobile app interface for our fitness tracking application. We need wireframes, mockups, and a complete design system.',
    category: 'Design',
    budget: { min: 25, max: 40, type: 'hourly' },
    skills: ['Figma', 'UI/UX Design', 'Mobile Design', 'Prototyping'],
    duration: '1 month',
    experienceLevel: 'intermediate',
    postedBy: {
      id: 'client2',
      name: 'Mike Chen',
      avatar: 'https://images.pexels.com/photos/2379004/pexels-photo-2379004.jpeg?auto=compress&cs=tinysrgb&w=150&h=150&dpr=1',
      rating: 4.9,
      totalJobs: 8
    },
    postedAt: '2024-01-14T14:30:00Z',
    applicants: 18,
    status: 'open',
    location: 'Remote'
  },
  {
    id: '3',
    title: 'Python Data Analyst for Marketing Campaign',
    description: 'Analyze customer data and marketing campaign performance using Python and create visualizations and reports.',
    category: 'Data Science',
    budget: { min: 2000, max: 3500, type: 'fixed' },
    skills: ['Python', 'Pandas', 'Matplotlib', 'SQL', 'Data Visualization'],
    duration: '3-4 weeks',
    experienceLevel: 'intermediate',
    postedBy: {
      id: 'client3',
      name: 'Emma Davis',
      avatar: 'https://images.pexels.com/photos/1239291/pexels-photo-1239291.jpeg?auto=compress&cs=tinysrgb&w=150&h=150&dpr=1',
      rating: 4.7,
      totalJobs: 15
    },
    postedAt: '2024-01-13T09:15:00Z',
    applicants: 31,
    status: 'open',
    location: 'Remote'
  }
];

export const mockUsers: User[] = [
  {
    id: 'freelancer1',
    name: 'Alex Rodriguez',
    email: 'alex@example.com',
    avatar: 'https://images.pexels.com/photos/1680172/pexels-photo-1680172.jpeg?auto=compress&cs=tinysrgb&w=150&h=150&dpr=1',
    type: 'freelancer',
    rating: 4.9,
    totalJobs: 45,
    skills: ['React', 'TypeScript', 'Node.js', 'Python', 'AWS'],
    hourlyRate: 65,
    bio: 'Full-stack developer with 6+ years of experience building scalable web applications.',
    location: 'San Francisco, CA',
    joinDate: '2020-03-15T00:00:00Z'
  },
  {
    id: 'freelancer2',
    name: 'Jessica Liu',
    email: 'jessica@example.com',
    avatar: 'https://images.pexels.com/photos/762020/pexels-photo-762020.jpeg?auto=compress&cs=tinysrgb&w=150&h=150&dpr=1',
    type: 'freelancer',
    rating: 4.8,
    totalJobs: 32,
    skills: ['Figma', 'UI/UX Design', 'Prototyping', 'User Research'],
    hourlyRate: 45,
    bio: 'UX/UI designer passionate about creating intuitive and beautiful user experiences.',
    location: 'New York, NY',
    joinDate: '2021-01-20T00:00:00Z'
  }
];

export const mockProposals: Proposal[] = [
  {
    id: 'prop1',
    jobId: '1',
    freelancerId: 'freelancer1',
    freelancer: mockUsers[0],
    coverLetter: 'I have extensive experience building e-commerce platforms with React and TypeScript. I can deliver a high-quality, scalable solution within your timeline.',
    proposedRate: 6500,
    proposedDuration: '2.5 months',
    submittedAt: '2024-01-15T12:00:00Z',
    status: 'pending'
  }
];