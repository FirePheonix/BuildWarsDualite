import { Bookmark } from '../types/bookmark';

export const initialBookmarks: Bookmark[] = [
  {
    id: '1',
    title: 'React Documentation',
    url: 'https://react.dev',
    description: 'The official React documentation with guides, tutorials, and API reference.',
    tags: ['react', 'frontend', 'javascript', 'documentation'],
    category: 'Development',
    createdAt: new Date('2024-01-15'),
    imageUrl: 'https://images.pexels.com/photos/11035380/pexels-photo-11035380.jpeg?auto=compress&cs=tinysrgb&w=800',
    favicon: '⚛️'
  },
  {
    id: '2',
    title: 'Tailwind CSS',
    url: 'https://tailwindcss.com',
    description: 'A utility-first CSS framework for rapidly building custom user interfaces.',
    tags: ['css', 'design', 'frontend', 'framework'],
    category: 'Design',
    createdAt: new Date('2024-01-14'),
    imageUrl: 'https://images.pexels.com/photos/196644/pexels-photo-196644.jpeg?auto=compress&cs=tinysrgb&w=800',
    favicon: '🎨'
  },
  {
    id: '3',
    title: 'OpenAI GPT-4',
    url: 'https://openai.com/gpt-4',
    description: 'GPT-4 is OpenAI\'s most advanced system, producing safer and more useful responses.',
    tags: ['ai', 'machine-learning', 'openai', 'technology'],
    category: 'AI & ML',
    createdAt: new Date('2024-01-13'),
    imageUrl: 'https://images.pexels.com/photos/8386434/pexels-photo-8386434.jpeg?auto=compress&cs=tinysrgb&w=800',
    favicon: '🤖'
  },
  {
    id: '4',
    title: 'Figma Design Tool',
    url: 'https://figma.com',
    description: 'Figma connects everyone in the design process so teams can deliver better products, faster.',
    tags: ['design', 'ui', 'ux', 'prototyping', 'collaboration'],
    category: 'Design',
    createdAt: new Date('2024-01-12'),
    imageUrl: 'https://images.pexels.com/photos/196655/pexels-photo-196655.jpeg?auto=compress&cs=tinysrgb&w=800',
    favicon: '🎨'
  },
  {
    id: '5',
    title: 'GitHub',
    url: 'https://github.com',
    description: 'Where the world builds software. Millions of developers collaborate here.',
    tags: ['git', 'development', 'open-source', 'collaboration'],
    category: 'Development',
    createdAt: new Date('2024-01-11'),
    imageUrl: 'https://images.pexels.com/photos/270348/pexels-photo-270348.jpeg?auto=compress&cs=tinysrgb&w=800',
    favicon: '🐙'
  },
  {
    id: '6',
    title: 'Unsplash',
    url: 'https://unsplash.com',
    description: 'Beautiful, free images and photos that you can download and use for any project.',
    tags: ['photography', 'images', 'free', 'creative'],
    category: 'Resources',
    createdAt: new Date('2024-01-10'),
    imageUrl: 'https://images.pexels.com/photos/167699/pexels-photo-167699.jpeg?auto=compress&cs=tinysrgb&w=800',
    favicon: '📸'
  },
  {
    id: '7',
    title: 'Stack Overflow',
    url: 'https://stackoverflow.com',
    description: 'Where developers learn, share, & build careers. The largest online community for programmers.',
    tags: ['programming', 'help', 'community', 'development'],
    category: 'Development',
    createdAt: new Date('2024-01-09'),
    imageUrl: 'https://images.pexels.com/photos/1181244/pexels-photo-1181244.jpeg?auto=compress&cs=tinysrgb&w=800',
    favicon: '📚'
  },
  {
    id: '8',
    title: 'Dribbble',
    url: 'https://dribbble.com',
    description: 'Discover the world\'s top designers & creatives. Get inspired by their work.',
    tags: ['design', 'inspiration', 'creative', 'portfolio'],
    category: 'Design',
    createdAt: new Date('2024-01-08'),
    imageUrl: 'https://images.pexels.com/photos/196645/pexels-photo-196645.jpeg?auto=compress&cs=tinysrgb&w=800',
    favicon: '🏀'
  }
];