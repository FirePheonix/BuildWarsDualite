import React, { createContext, useContext, useState, useMemo } from 'react';
import { Bookmark, BookmarkContextType } from '../types/bookmark';
import { initialBookmarks } from '../data/sampleData';

const BookmarkContext = createContext<BookmarkContextType | undefined>(undefined);

export const useBookmarks = () => {
  const context = useContext(BookmarkContext);
  if (!context) {
    throw new Error('useBookmarks must be used within a BookmarkProvider');
  }
  return context;
};

export const BookmarkProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [bookmarks, setBookmarks] = useState<Bookmark[]>(initialBookmarks);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedTags, setSelectedTags] = useState<string[]>([]);
  const [selectedCategory, setSelectedCategory] = useState('All');
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingBookmark, setEditingBookmark] = useState<Bookmark | null>(null);

  const filteredBookmarks = useMemo(() => {
    return bookmarks.filter(bookmark => {
      const matchesSearch = searchQuery === '' || 
        bookmark.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
        bookmark.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
        bookmark.tags.some(tag => tag.toLowerCase().includes(searchQuery.toLowerCase()));

      const matchesTags = selectedTags.length === 0 || 
        selectedTags.every(tag => bookmark.tags.includes(tag));

      const matchesCategory = selectedCategory === 'All' || bookmark.category === selectedCategory;

      return matchesSearch && matchesTags && matchesCategory;
    });
  }, [bookmarks, searchQuery, selectedTags, selectedCategory]);

  const addBookmark = (bookmarkData: Omit<Bookmark, 'id' | 'createdAt'>) => {
    const newBookmark: Bookmark = {
      ...bookmarkData,
      id: Date.now().toString(),
      createdAt: new Date(),
    };
    setBookmarks(prev => [newBookmark, ...prev]);
  };

  const updateBookmark = (id: string, bookmarkData: Partial<Bookmark>) => {
    setBookmarks(prev => 
      prev.map(bookmark => 
        bookmark.id === id ? { ...bookmark, ...bookmarkData } : bookmark
      )
    );
  };

  const deleteBookmark = (id: string) => {
    setBookmarks(prev => prev.filter(bookmark => bookmark.id !== id));
  };

  const toggleTag = (tag: string) => {
    setSelectedTags(prev => 
      prev.includes(tag) 
        ? prev.filter(t => t !== tag)
        : [...prev, tag]
    );
  };

  const openModal = () => {
    setIsModalOpen(true);
    setEditingBookmark(null);
  };

  const closeModal = () => {
    setIsModalOpen(false);
    setEditingBookmark(null);
  };

  const contextValue: BookmarkContextType = {
    bookmarks,
    filteredBookmarks,
    searchQuery,
    selectedTags,
    selectedCategory,
    isModalOpen,
    editingBookmark,
    addBookmark,
    updateBookmark,
    deleteBookmark,
    setSearchQuery,
    toggleTag,
    setSelectedCategory,
    openModal,
    closeModal,
    setEditingBookmark,
  };

  return (
    <BookmarkContext.Provider value={contextValue}>
      {children}
    </BookmarkContext.Provider>
  );
};