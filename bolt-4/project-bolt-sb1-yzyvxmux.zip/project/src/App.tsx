import React, { useState, useMemo } from 'react';
import { Header } from './components/Header';
import { BookmarkGrid } from './components/BookmarkGrid';
import { AddBookmarkModal } from './components/AddBookmarkModal';
import { Sidebar } from './components/Sidebar';
import { BookmarkProvider } from './context/BookmarkContext';

function App() {
  return (
    <BookmarkProvider>
      <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-indigo-100">
        <Header />
        <div className="flex">
          <Sidebar />
          <main className="flex-1 p-6">
            <BookmarkGrid />
          </main>
        </div>
        <AddBookmarkModal />
      </div>
    </BookmarkProvider>
  );
}

export default App;