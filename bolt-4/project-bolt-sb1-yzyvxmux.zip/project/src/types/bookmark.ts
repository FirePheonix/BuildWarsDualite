export interface Bookmark {
  id: string;
  title: string;
  url: string;
  description: string;
  tags: string[];
  category: string;
  createdAt: Date;
  imageUrl?: string;
  favicon?: string;
}

export interface BookmarkContextType {
  bookmarks: Bookmark[];
  filteredBookmarks: Bookmark[];
  searchQuery: string;
  selectedTags: string[];
  selectedCategory: string;
  isModalOpen: boolean;
  editingBookmark: Bookmark | null;
  addBookmark: (bookmark: Omit<Bookmark, 'id' | 'createdAt'>) => void;
  updateBookmark: (id: string, bookmark: Partial<Bookmark>) => void;
  deleteBookmark: (id: string) => void;
  setSearchQuery: (query: string) => void;
  toggleTag: (tag: string) => void;
  setSelectedCategory: (category: string) => void;
  openModal: () => void;
  closeModal: () => void;
  setEditingBookmark: (bookmark: Bookmark | null) => void;
}