import React from 'react';
import { Bookmark, Plus } from 'lucide-react';
import { useBookmarks } from '../context/BookmarkContext';

export const EmptyState: React.FC = () => {
  const { openModal, searchQuery, selectedTags } = useBookmarks();
  
  const isFiltered = searchQuery || selectedTags.length > 0;

  return (
    <div className="flex flex-col items-center justify-center min-h-[60vh] text-center">
      <div className="bg-gradient-to-r from-blue-100 to-purple-100 p-6 rounded-full mb-6">
        <Bookmark className="w-12 h-12 text-blue-500" />
      </div>
      
      <h3 className="text-2xl font-bold text-gray-900 mb-2">
        {isFiltered ? 'No bookmarks found' : 'No bookmarks yet'}
      </h3>
      
      <p className="text-gray-600 mb-8 max-w-md">
        {isFiltered 
          ? 'Try adjusting your search or filters to find what you\'re looking for.'
          : 'Start building your collection by adding your first bookmark. Save interesting links, articles, and resources.'
        }
      </p>

      {!isFiltered && (
        <button
          onClick={openModal}
          className="flex items-center space-x-2 bg-gradient-to-r from-blue-500 to-purple-600 text-white px-6 py-3 rounded-xl hover:from-blue-600 hover:to-purple-700 transition-all duration-200 shadow-lg hover:shadow-xl transform hover:-translate-y-0.5"
        >
          <Plus className="w-5 h-5" />
          <span className="font-medium">Add Your First Bookmark</span>
        </button>
      )}
    </div>
  );
};