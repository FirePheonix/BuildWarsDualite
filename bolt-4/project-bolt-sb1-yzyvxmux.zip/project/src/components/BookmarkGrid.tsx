import React from 'react';
import { BookmarkCard } from './BookmarkCard';
import { useBookmarks } from '../context/BookmarkContext';
import { EmptyState } from './EmptyState';

export const BookmarkGrid: React.FC = () => {
  const { filteredBookmarks } = useBookmarks();

  if (filteredBookmarks.length === 0) {
    return <EmptyState />;
  }

  return (
    <div className="columns-1 md:columns-2 lg:columns-3 xl:columns-4 gap-6 space-y-6">
      {filteredBookmarks.map((bookmark, index) => (
        <BookmarkCard 
          key={bookmark.id} 
          bookmark={bookmark} 
          delay={index * 100}
        />
      ))}
    </div>
  );
};