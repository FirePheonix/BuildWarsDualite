import React, { useMemo } from 'react';
import { Hash, Grid, Filter } from 'lucide-react';
import { useBookmarks } from '../context/BookmarkContext';

export const Sidebar: React.FC = () => {
  const { bookmarks, selectedTags, selectedCategory, toggleTag, setSelectedCategory } = useBookmarks();

  const allTags = useMemo(() => {
    const tags = new Set<string>();
    bookmarks.forEach(bookmark => {
      bookmark.tags.forEach(tag => tags.add(tag));
    });
    return Array.from(tags).sort();
  }, [bookmarks]);

  const categories = useMemo(() => {
    const cats = new Set(['All']);
    bookmarks.forEach(bookmark => cats.add(bookmark.category));
    return Array.from(cats);
  }, [bookmarks]);

  const tagColors = [
    'bg-blue-100 text-blue-700 border-blue-200',
    'bg-purple-100 text-purple-700 border-purple-200',
    'bg-green-100 text-green-700 border-green-200',
    'bg-yellow-100 text-yellow-700 border-yellow-200',
    'bg-pink-100 text-pink-700 border-pink-200',
    'bg-indigo-100 text-indigo-700 border-indigo-200',
  ];

  return (
    <aside className="w-64 bg-white/50 backdrop-blur-sm border-r border-white/20 h-screen sticky top-16 overflow-y-auto">
      <div className="p-6">
        {/* Categories */}
        <div className="mb-8">
          <div className="flex items-center space-x-2 mb-4">
            <Grid className="w-5 h-5 text-gray-600" />
            <h3 className="font-semibold text-gray-800">Categories</h3>
          </div>
          <div className="space-y-2">
            {categories.map(category => (
              <button
                key={category}
                onClick={() => setSelectedCategory(category)}
                className={`w-full text-left px-3 py-2 rounded-lg transition-colors ${
                  selectedCategory === category
                    ? 'bg-blue-100 text-blue-700 font-medium'
                    : 'text-gray-600 hover:bg-gray-100'
                }`}
              >
                {category}
              </button>
            ))}
          </div>
        </div>

        {/* Tags */}
        <div>
          <div className="flex items-center space-x-2 mb-4">
            <Hash className="w-5 h-5 text-gray-600" />
            <h3 className="font-semibold text-gray-800">Tags</h3>
            {selectedTags.length > 0 && (
              <span className="bg-blue-100 text-blue-700 px-2 py-0.5 rounded-full text-xs font-medium">
                {selectedTags.length}
              </span>
            )}
          </div>
          <div className="flex flex-wrap gap-2">
            {allTags.map((tag, index) => {
              const isSelected = selectedTags.includes(tag);
              const colorClass = tagColors[index % tagColors.length];
              
              return (
                <button
                  key={tag}
                  onClick={() => toggleTag(tag)}
                  className={`px-3 py-1.5 rounded-full text-sm font-medium border transition-all duration-200 ${
                    isSelected
                      ? 'bg-blue-500 text-white border-blue-500 shadow-md transform scale-105'
                      : `${colorClass} hover:shadow-sm hover:scale-105`
                  }`}
                >
                  {tag}
                </button>
              );
            })}
          </div>
        </div>
      </div>
    </aside>
  );
};