import React from 'react';
import { ExternalLink, Edit2, Trash2, Calendar, Tag } from 'lucide-react';
import { Bookmark } from '../types/bookmark';
import { useBookmarks } from '../context/BookmarkContext';

interface BookmarkCardProps {
  bookmark: Bookmark;
  delay?: number;
}

export const BookmarkCard: React.FC<BookmarkCardProps> = ({ bookmark, delay = 0 }) => {
  const { deleteBookmark, setEditingBookmark, openModal } = useBookmarks();

  const handleEdit = () => {
    setEditingBookmark(bookmark);
    openModal();
  };

  const handleDelete = () => {
    if (confirm('Are you sure you want to delete this bookmark?')) {
      deleteBookmark(bookmark.id);
    }
  };

  const tagColors = [
    'bg-blue-100 text-blue-700',
    'bg-purple-100 text-purple-700',
    'bg-green-100 text-green-700',
    'bg-yellow-100 text-yellow-700',
    'bg-pink-100 text-pink-700',
    'bg-indigo-100 text-indigo-700',
  ];

  return (
    <div 
      className="break-inside-avoid mb-6 bg-white rounded-2xl shadow-sm hover:shadow-xl transition-all duration-300 overflow-hidden group transform hover:-translate-y-1 animate-fade-in-up"
      style={{ animationDelay: `${delay}ms` }}
    >
      {/* Image */}
      {bookmark.imageUrl && (
        <div className="relative overflow-hidden">
          <img
            src={bookmark.imageUrl}
            alt={bookmark.title}
            className="w-full h-48 object-cover group-hover:scale-105 transition-transform duration-300"
            loading="lazy"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-black/20 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
        </div>
      )}

      {/* Content */}
      <div className="p-5">
        <div className="flex items-start justify-between mb-3">
          <div className="flex items-center space-x-2">
            {bookmark.favicon && (
              <span className="text-xl">{bookmark.favicon}</span>
            )}
            <h3 className="font-semibold text-gray-900 line-clamp-2 group-hover:text-blue-600 transition-colors">
              {bookmark.title}
            </h3>
          </div>
          <div className="flex space-x-1 opacity-0 group-hover:opacity-100 transition-opacity">
            <button
              onClick={handleEdit}
              className="p-1.5 text-gray-400 hover:text-blue-500 hover:bg-blue-50 rounded-lg transition-all"
            >
              <Edit2 className="w-4 h-4" />
            </button>
            <button
              onClick={handleDelete}
              className="p-1.5 text-gray-400 hover:text-red-500 hover:bg-red-50 rounded-lg transition-all"
            >
              <Trash2 className="w-4 h-4" />
            </button>
          </div>
        </div>

        {bookmark.description && (
          <p className="text-gray-600 text-sm mb-4 line-clamp-3">
            {bookmark.description}
          </p>
        )}

        {/* Tags */}
        {bookmark.tags.length > 0 && (
          <div className="flex flex-wrap gap-1.5 mb-4">
            {bookmark.tags.map((tag, index) => (
              <span
                key={tag}
                className={`px-2 py-1 rounded-full text-xs font-medium ${
                  tagColors[index % tagColors.length]
                }`}
              >
                #{tag}
              </span>
            ))}
          </div>
        )}

        {/* Footer */}
        <div className="flex items-center justify-between pt-3 border-t border-gray-100">
          <div className="flex items-center space-x-3 text-xs text-gray-500">
            <span className="flex items-center space-x-1">
              <Calendar className="w-3 h-3" />
              <span>{new Date(bookmark.createdAt).toLocaleDateString()}</span>
            </span>
            <span className="flex items-center space-x-1">
              <Tag className="w-3 h-3" />
              <span>{bookmark.category}</span>
            </span>
          </div>
          <a
            href={bookmark.url}
            target="_blank"
            rel="noopener noreferrer"
            className="flex items-center space-x-1 text-blue-500 hover:text-blue-600 transition-colors group"
          >
            <span className="text-xs font-medium">Visit</span>
            <ExternalLink className="w-3 h-3 group-hover:translate-x-0.5 group-hover:-translate-y-0.5 transition-transform" />
          </a>
        </div>
      </div>
    </div>
  );
};